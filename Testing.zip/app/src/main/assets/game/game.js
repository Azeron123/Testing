// ==========================================
// FANTASY RPG: OAKHAVEN VILLAGE
// Cainos Pixel-Art Tileset Integration
// 16:9 Canvas Resolution: 960 x 540
// ==========================================

const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

const VIRTUAL_WIDTH = 960;
const VIRTUAL_HEIGHT = 540;
const WORLD_WIDTH = 1800;
const WORLD_HEIGHT = 1200;

// Enable crisp pixel art rendering
ctx.imageSmoothingEnabled = false;

// ------------------------------------------
// Cainos Pixel-Art Asset Loader
// ------------------------------------------
const ASSETS = {};
const assetSources = {
  grass: "assets/grass.png",
  stoneGround: "assets/stone_ground.png",
  wall: "assets/wall.png",
  struct: "assets/struct.png",
  props: "assets/props.png",
  propsShadow: "assets/shadow.png",
  plant: "assets/plant.png",
  plantShadow: "assets/shadow_plant.png",
  knightTurnaround: "assets/knight_turnaround.png"
};

// Knight Sprite Frames from turnaround_b4d78650.json (512x64, cell: 64x64, pivot: [32, 56])
const KNIGHT_FRAMES = {
  "south":      { index: 0, sx: 0,   sy: 0, sw: 64, sh: 64, pivotX: 32, pivotY: 56 },
  "south-east": { index: 1, sx: 64,  sy: 0, sw: 64, sh: 64, pivotX: 32, pivotY: 56 },
  "east":       { index: 2, sx: 128, sy: 0, sw: 64, sh: 64, pivotX: 32, pivotY: 56 },
  "north-east": { index: 3, sx: 192, sy: 0, sw: 64, sh: 64, pivotX: 32, pivotY: 56 },
  "north":      { index: 4, sx: 256, sy: 0, sw: 64, sh: 64, pivotX: 32, pivotY: 56 },
  "north-west": { index: 5, sx: 320, sy: 0, sw: 64, sh: 64, pivotX: 32, pivotY: 56 },
  "west":       { index: 6, sx: 384, sy: 0, sw: 64, sh: 64, pivotX: 32, pivotY: 56 },
  "south-west": { index: 7, sx: 448, sy: 0, sw: 64, sh: 64, pivotX: 32, pivotY: 56 }
};

let assetsLoaded = false;
let loadedAssetsCount = 0;
const totalAssets = Object.keys(assetSources).length;

let grassPattern = null;
let stonePlazaPattern = null;

for (const key in assetSources) {
  const img = new Image();
  img.src = assetSources[key];
  img.onload = () => {
    loadedAssetsCount++;
    if (loadedAssetsCount >= totalAssets) {
      assetsLoaded = true;
      initMapPatterns();
    }
  };
  ASSETS[key] = img;
}

function initMapPatterns() {
  // 1. Create seamless Grass Pattern from top-left (0,0,128,128) of TX_Tileset_Grass
  if (ASSETS.grass && ASSETS.grass.naturalWidth > 0) {
    const grassCanvas = document.createElement("canvas");
    grassCanvas.width = 128;
    grassCanvas.height = 128;
    const gCtx = grassCanvas.getContext("2d");
    gCtx.imageSmoothingEnabled = false;
    gCtx.drawImage(ASSETS.grass, 0, 0, 128, 128, 0, 0, 128, 128);
    grassPattern = ctx.createPattern(grassCanvas, "repeat");
  }

  // 2. Create Plaza Stone Ground Pattern from (0,0,128,128) of TX_Tileset_Stone_Ground
  if (ASSETS.stoneGround && ASSETS.stoneGround.naturalWidth > 0) {
    const stoneCanvas = document.createElement("canvas");
    stoneCanvas.width = 128;
    stoneCanvas.height = 128;
    const sCtx = stoneCanvas.getContext("2d");
    sCtx.imageSmoothingEnabled = false;
    sCtx.drawImage(ASSETS.stoneGround, 0, 0, 128, 128, 0, 0, 128, 128);
    stonePlazaPattern = ctx.createPattern(stoneCanvas, "repeat");
  }
}

// ------------------------------------------
// Cainos Pixel-Art Sprite Catalog
// ------------------------------------------
const SPRITES = {
  // Trees from plant.png & plantShadow.png (512x512)
  tree1: { x: 24, y: 14, w: 113, h: 139, anchorX: 56, anchorY: 132, trunkR: 16 },
  tree2: { x: 161, y: 17, w: 95, h: 136, anchorX: 47, anchorY: 130, trunkR: 15 },
  tree3: { x: 295, y: 31, w: 79, h: 120, anchorX: 39, anchorY: 114, trunkR: 14 },

  // Bushes from plant.png & plantShadow.png
  bush1: { x: 38, y: 198, w: 22, h: 19, anchorX: 11, anchorY: 14, colR: 10 },
  bush2: { x: 98, y: 195, w: 27, h: 25, anchorX: 13, anchorY: 18, colR: 12 },
  bush3: { x: 156, y: 190, w: 38, h: 32, anchorX: 19, anchorY: 24, colR: 16 },
  bush4: { x: 216, y: 185, w: 47, h: 42, anchorX: 23, anchorY: 32, colR: 18 },
  bush5: { x: 282, y: 186, w: 39, h: 45, anchorX: 19, anchorY: 34, colR: 17 },
  bush6: { x: 346, y: 190, w: 40, h: 35, anchorX: 20, anchorY: 26, colR: 16 },

  // Props from props.png & propsShadow.png (512x512)
  chestClosed: { x: 96, y: 30, w: 32, h: 31, anchorX: 16, anchorY: 24, colR: 14 },
  chestOpen: { x: 96, y: 76, w: 32, h: 49, anchorX: 16, anchorY: 42, colR: 14 },
  crateTall: { x: 160, y: 18, w: 32, h: 46, anchorX: 16, anchorY: 38, colR: 15 },
  crateSmall: { x: 163, y: 86, w: 26, h: 39, anchorX: 13, anchorY: 32, colR: 13 },
  barrel: { x: 162, y: 153, w: 28, h: 36, anchorX: 14, anchorY: 28, colR: 13 },
  clayPot: { x: 165, y: 217, w: 21, h: 34, anchorX: 10, anchorY: 26, colR: 10 },
  clayPotSmall: { x: 164, y: 288, w: 25, h: 27, anchorX: 12, anchorY: 21, colR: 10 },
  clayJug: { x: 165, y: 348, w: 21, h: 32, anchorX: 10, anchorY: 25, colR: 9 },
  benchFront: { x: 292, y: 19, w: 56, h: 41, anchorX: 28, anchorY: 32, colW: 52, colH: 18 },
  tombSword: { x: 288, y: 87, w: 64, h: 36, anchorX: 32, anchorY: 28, colW: 60, colH: 26 },
  statueMaiden: { x: 445, y: 21, w: 37, h: 72, anchorX: 18, anchorY: 64, colR: 16 },
  doorWood: { x: 29, y: 103, w: 37, h: 50 },
  signEast: { x: 99, y: 160, w: 27, h: 32, anchorX: 13, anchorY: 27, colR: 8 },
  signWest: { x: 96, y: 224, w: 27, h: 32, anchorX: 13, anchorY: 27, colR: 8 },
  pillarRune: { x: 227, y: 9, w: 26, h: 52, anchorX: 13, anchorY: 44, colR: 12 },
  magicCircle: { x: 353, y: 269, w: 94, h: 72, anchorX: 47, anchorY: 36 },
  well: { x: 420, y: 359, w: 55, h: 49, anchorX: 27, anchorY: 35, colR: 24 },
  boulder: { x: 3, y: 430, w: 57, h: 42, anchorX: 28, anchorY: 32, colR: 24 },
  stoneSmall: { x: 40, y: 490, w: 16, h: 14, anchorX: 8, anchorY: 10 },
  stonePile: { x: 68, y: 482, w: 121, h: 27, anchorX: 60, anchorY: 20 },

  // From struct.png (512x512)
  bridgeArch: { x: 408, y: 26, w: 80, h: 64 },
  bridgeTop: { x: 32, y: 32, w: 64, h: 96 },

  // From wall.png (512x512)
  wallHorizontal: { x: 32, y: 192, w: 128, h: 64 },
  wallWindow: { x: 192, y: 192, w: 32, h: 64 },
  wallSegment: { x: 32, y: 288, w: 64, h: 64 }
};

// ------------------------------------------
// Web Audio Sound Synthesizer (No external audio)
// ------------------------------------------
let audioCtx = null;
let soundEnabled = true;

function initAudio() {
  if (!audioCtx) {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (AudioContext) {
      audioCtx = new AudioContext();
    }
  }
  if (audioCtx && audioCtx.state === "suspended") {
    audioCtx.resume();
  }
}

function playSound(type) {
  if (!soundEnabled || !audioCtx) return;
  try {
    const now = audioCtx.currentTime;
    if (type === "swing") {
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(420, now);
      osc.frequency.exponentialRampToValueAtTime(140, now + 0.12);
      gain.gain.setValueAtTime(0.25, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.12);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start(now);
      osc.stop(now + 0.13);
    } else if (type === "hit") {
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = "triangle";
      osc.frequency.setValueAtTime(260, now);
      osc.frequency.exponentialRampToValueAtTime(70, now + 0.15);
      gain.gain.setValueAtTime(0.35, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.15);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start(now);
      osc.stop(now + 0.16);
    } else if (type === "coin") {
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(987, now);
      osc.frequency.setValueAtTime(1318, now + 0.08);
      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.22);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start(now);
      osc.stop(now + 0.23);
    } else if (type === "dash") {
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = "sawtooth";
      osc.frequency.setValueAtTime(300, now);
      osc.frequency.exponentialRampToValueAtTime(100, now + 0.18);
      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.18);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start(now);
      osc.stop(now + 0.19);
    } else if (type === "grass") {
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(500, now);
      osc.frequency.exponentialRampToValueAtTime(200, now + 0.06);
      gain.gain.setValueAtTime(0.08, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.06);
    } else if (type === "levelup") {
      const notes = [523.25, 659.25, 783.99, 1046.5]; // C5 - E5 - G5 - C6 chime
      notes.forEach((freq, idx) => {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = "triangle";
        const noteStart = now + idx * 0.08;
        osc.frequency.setValueAtTime(freq, noteStart);
        gain.gain.setValueAtTime(0.22, noteStart);
        gain.gain.exponentialRampToValueAtTime(0.01, noteStart + 0.28);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start(noteStart);
        osc.stop(noteStart + 0.29);
      });
    }
  } catch (e) {
    // Audio context may be restricted before touch
  }
}

// ------------------------------------------
// Virtual Touch Controls (Unchanged)
// ------------------------------------------
const joystick = {
  active: false,
  touchId: null,
  baseX: 130,
  baseY: VIRTUAL_HEIGHT - 120,
  currX: 130,
  currY: VIRTUAL_HEIGHT - 120,
  radius: 65,
  knobRadius: 30,
  dx: 0,
  dy: 0,
  force: 0,
  angle: 0
};

const attackButton = {
  x: VIRTUAL_WIDTH - 100,
  y: VIRTUAL_HEIGHT - 100,
  radius: 52,
  pressed: false,
  touchId: null,
  label: "ATTACK"
};

const dashButton = {
  x: VIRTUAL_WIDTH - 200,
  y: VIRTUAL_HEIGHT - 85,
  radius: 36,
  pressed: false,
  touchId: null,
  label: "DASH"
};

const interactButton = {
  x: VIRTUAL_WIDTH - 90,
  y: VIRTUAL_HEIGHT - 200,
  radius: 34,
  pressed: false,
  touchId: null,
  label: "TALK"
};

const keys = {
  ArrowUp: false,
  ArrowDown: false,
  ArrowLeft: false,
  ArrowRight: false,
  KeyW: false,
  KeyS: false,
  KeyA: false,
  KeyD: false,
  Space: false,
  KeyJ: false,
  KeyK: false,
  KeyE: false
};

// ------------------------------------------
// Player State (Unchanged)
// ------------------------------------------
const player = {
  x: 540,
  y: 580,
  radius: 16,
  speed: 180,
  vx: 0,
  vy: 0,
  facing: "down",
  moving: false,
  walkTimer: 0,
  level: 1,
  exp: 0,
  maxExp: 50,

  // Base & Allocated Stats
  str: 10, // Strength: Increases Attack (+2 Attack per STR)
  vit: 10, // Vitality: Increases Max HP (+15 Max HP per VIT) & Defense (+1.5 Defense per VIT)
  int: 10, // Intelligence: Increases Max MP (+10 Max MP per INT)
  dex: 10, // Dexterity: Increases Attack Speed (-0.005s attack duration & -0.006s cooldown per DEX)
  statPoints: 0,

  // Derived Attributes
  hp: 100,
  maxHp: 100,
  mp: 50,
  maxMp: 50,
  stamina: 100,
  maxStamina: 100,
  attack: 25,
  defense: 15,
  gold: 0,

  isAttacking: false,
  attackProgress: 0,
  attackDuration: 0.24,
  attackCooldown: 0,
  comboCount: 0,

  isDashing: false,
  dashProgress: 0,
  dashDuration: 0.22,
  dashCooldown: 0,
  dashVx: 0,
  dashVy: 0,

  hurtTimer: 0
};

// ------------------------------------------
// EXP, Leveling, Stats & Persistence
// ------------------------------------------
const SAVE_KEY = "knight_rpg_save_data";

function getExpRequiredForLevel(lvl) {
  return Math.round(50 * Math.pow(1.35, lvl - 1));
}

function recalculatePlayerStats(preserveRatios = false) {
  const prevMaxHp = player.maxHp;
  const prevMaxMp = player.maxMp;

  // Level base + stat contributions
  // Base HP: 70 + (Level - 1) * 15 + Vitality * 15
  player.maxHp = 70 + (player.level - 1) * 15 + player.vit * 15;
  // Base MP: 30 + (Level - 1) * 10 + Intelligence * 10
  player.maxMp = 30 + (player.level - 1) * 10 + player.int * 10;
  // Attack: Base 5 + (Level - 1) * 2 + Strength * 2
  player.attack = 5 + (player.level - 1) * 2 + player.str * 2;
  // Defense: Base 2 + (Level - 1) * 1 + Math.floor(Vitality * 1.5)
  player.defense = 2 + (player.level - 1) * 1 + Math.floor(player.vit * 1.5);
  // Attack duration (Attack Speed): Dexterity reduces swing duration smoothly
  // At DEX 10: 0.24s; at DEX 30: ~0.16s
  player.attackDuration = Math.max(0.12, 0.29 - player.dex * 0.005);

  if (preserveRatios && prevMaxHp > 0 && prevMaxMp > 0) {
    player.hp = Math.min(player.maxHp, Math.round((player.hp / prevMaxHp) * player.maxHp));
    player.mp = Math.min(player.maxMp, Math.round((player.mp / prevMaxMp) * player.maxMp));
  } else {
    player.hp = Math.min(player.maxHp, player.hp || player.maxHp);
    player.mp = Math.min(player.maxMp, player.mp || player.maxMp);
  }
}

function allocateStatPoint(stat) {
  if (player.statPoints <= 0) return false;
  if (stat === "str") player.str++;
  else if (stat === "vit") player.vit++;
  else if (stat === "int") player.int++;
  else if (stat === "dex") player.dex++;
  else return false;

  player.statPoints--;
  recalculatePlayerStats(true);
  playSound("coin");
  savePlayerProgress();
  return true;
}

function savePlayerProgress() {
  try {
    const saveData = {
      level: player.level,
      exp: player.exp,
      maxExp: player.maxExp,
      hp: player.hp,
      mp: player.mp,
      gold: player.gold,
      str: player.str,
      vit: player.vit,
      int: player.int,
      dex: player.dex,
      statPoints: player.statPoints,
      savedAt: Date.now()
    };
    localStorage.setItem(SAVE_KEY, JSON.stringify(saveData));
  } catch (err) {
    console.warn("Could not save to localStorage:", err);
  }
}

function loadPlayerProgress() {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (raw) {
      const data = JSON.parse(raw);
      if (typeof data.level === "number" && data.level >= 1) {
        player.level = data.level;
        player.maxExp = getExpRequiredForLevel(player.level);
        player.exp = Math.max(0, Math.min(player.maxExp - 1, data.exp || 0));

        player.str = typeof data.str === "number" ? Math.max(10, data.str) : 10;
        player.vit = typeof data.vit === "number" ? Math.max(10, data.vit) : 10;
        player.int = typeof data.int === "number" ? Math.max(10, data.int) : 10;
        player.dex = typeof data.dex === "number" ? Math.max(10, data.dex) : 10;
        player.statPoints = typeof data.statPoints === "number" ? Math.max(0, data.statPoints) : 0;

        recalculatePlayerStats(false);

        if (typeof data.hp === "number") player.hp = Math.min(player.maxHp, Math.max(1, data.hp));
        if (typeof data.mp === "number") player.mp = Math.min(player.maxMp, Math.max(0, data.mp));
        if (typeof data.gold === "number") player.gold = data.gold;
        return;
      }
    }
  } catch (err) {
    console.warn("Could not load from localStorage:", err);
  }
  recalculatePlayerStats(false);
}

loadPlayerProgress();

function gainExp(amount) {
  player.exp += amount;

  damageTexts.push({
    text: `+${amount} EXP`,
    x: player.x,
    y: player.y - 45,
    life: 0.9,
    color: "#48cae4"
  });

  // Check for level up(s)
  while (player.exp >= player.maxExp) {
    player.exp -= player.maxExp;
    player.level += 1;
    player.maxExp = getExpRequiredForLevel(player.level);

    // Give 3 stat points per level up
    player.statPoints += 3;

    // Recalculate stats and fully restore HP & MP on level up!
    recalculatePlayerStats(false);
    player.hp = player.maxHp;
    player.mp = player.maxMp;

    playSound("levelup");
    camera.shake = 8;

    damageTexts.push({
      text: `★ LEVEL UP! Lv. ${player.level} (+3 Stat Points!) ★`,
      x: player.x,
      y: player.y - 65,
      life: 2.4,
      color: "#ffd166",
      isCrit: true
    });

    // Celebratory radiant golden particles around the Knight
    for (let k = 0; k < 25; k++) {
      const pAngle = (k / 25) * Math.PI * 2;
      const pSpeed = 60 + Math.random() * 80;
      particles.push({
        x: player.x,
        y: player.y - 18,
        vx: Math.cos(pAngle) * pSpeed,
        vy: Math.sin(pAngle) * pSpeed,
        life: 0.7 + Math.random() * 0.3,
        maxLife: 1.0,
        color: k % 2 === 0 ? "#ffd166" : "#48cae4",
        size: 4 + Math.random() * 3
      });
    }
  }

  savePlayerProgress();
}

// ------------------------------------------
// Game World & Map Layout with Cainos Assets
// ------------------------------------------
const obstacles = [];
const bushes = [];
const dummies = [];
const slimes = [];
const npcs = [];
const propsList = [];
const particles = [];
const damageTexts = [];
const clouds = [];

function buildCainosVillageMap() {
  obstacles.length = 0;
  bushes.length = 0;
  dummies.length = 0;
  slimes.length = 0;
  npcs.length = 0;
  propsList.length = 0;

  // Outer Map Boundaries
  obstacles.push({ x: 0, y: 0, w: WORLD_WIDTH, h: 40 });
  obstacles.push({ x: 0, y: WORLD_HEIGHT - 40, w: WORLD_WIDTH, h: 40 });
  obstacles.push({ x: 0, y: 0, w: 40, h: WORLD_HEIGHT });
  obstacles.push({ x: WORLD_WIDTH - 40, y: 0, w: 40, h: WORLD_HEIGHT });

  // 1. Mayor's Manor (Stone walls from wall.png, wood door, red roof)
  obstacles.push({
    type: "cainos_building",
    name: "Mayor's Manor",
    x: 410,
    y: 180,
    w: 260,
    h: 170,
    doorX: 520,
    doorY: 300,
    wallType: "manor",
    roofHue: "#8f2d22"
  });

  // 2. Apothecary / Herbalist Cottage
  obstacles.push({
    type: "cainos_building",
    name: "Apothecary",
    x: 170,
    y: 420,
    w: 200,
    h: 155,
    doorX: 250,
    doorY: 530,
    wallType: "herbalist",
    roofHue: "#2d5a3f"
  });

  // 3. Blacksmith Forge (Ironhide Smithy)
  obstacles.push({
    type: "cainos_building",
    name: "Ironhide Smithy",
    x: 770,
    y: 360,
    w: 220,
    h: 155,
    doorX: 860,
    doorY: 470,
    wallType: "smithy",
    isSmithy: true,
    roofHue: "#403d39"
  });

  // Central Village Well (from props.png)
  obstacles.push({
    type: "cainos_well",
    x: 540,
    y: 530,
    radius: 26
  });

  // Training Grounds Walls (Stone wall segments from wall.png)
  obstacles.push({ type: "cainos_wall", x: 740, y: 720, w: 260, h: 16 });
  obstacles.push({ type: "cainos_wall", x: 740, y: 720, w: 16, h: 220 });
  obstacles.push({ type: "cainos_wall", x: 990, y: 720, w: 16, h: 220 });

  // Training Dummies (Straw target dummies)
  dummies.push({ x: 820, y: 810, radius: 20, hp: 100, maxHp: 100, wobble: 0, hitTime: 0 });
  dummies.push({ x: 910, y: 830, radius: 20, hp: 100, maxHp: 100, wobble: 0, hitTime: 0 });

  // Cainos Oak Trees (plant.png) with matching shadows
  const trees = [
    { x: 120, y: 150, sprite: "tree1" },
    { x: 260, y: 130, sprite: "tree2" },
    { x: 100, y: 310, sprite: "tree3" },
    { x: 140, y: 730, sprite: "tree1" },
    { x: 280, y: 790, sprite: "tree2" },
    { x: 130, y: 950, sprite: "tree1" },
    { x: 400, y: 990, sprite: "tree2" },
    { x: 580, y: 1030, sprite: "tree1" },
    { x: 740, y: 170, sprite: "tree2" },
    { x: 920, y: 190, sprite: "tree3" },
    { x: 1060, y: 330, sprite: "tree1" },
    { x: 1080, y: 570, sprite: "tree2" },
    { x: 1050, y: 890, sprite: "tree3" },
    { x: 1100, y: 1050, sprite: "tree1" },
    { x: 1540, y: 190, sprite: "tree1" },
    { x: 1630, y: 440, sprite: "tree2" },
    { x: 1560, y: 790, sprite: "tree1" },
    { x: 1640, y: 1030, sprite: "tree2" }
  ];

  trees.forEach(t => {
    const sp = SPRITES[t.sprite];
    obstacles.push({
      type: "cainos_tree",
      x: t.x,
      y: t.y,
      spriteKey: t.sprite,
      radius: sp.trunkR
    });
  });

  // Cainos Cuttable Bushes (plant.png)
  const bushCoords = [
    { x: 340, y: 370, sprite: "bush4" },
    { x: 375, y: 390, sprite: "bush3" },
    { x: 350, y: 660, sprite: "bush2" },
    { x: 440, y: 750, sprite: "bush5" },
    { x: 480, y: 780, sprite: "bush6" },
    { x: 670, y: 660, sprite: "bush3" },
    { x: 710, y: 630, sprite: "bush4" },
    { x: 730, y: 890, sprite: "bush2" },
    { x: 690, y: 930, sprite: "bush1" },
    { x: 1140, y: 490, sprite: "bush3" },
    { x: 1180, y: 530, sprite: "bush4" },
    { x: 1160, y: 730, sprite: "bush5" },
    { x: 1460, y: 490, sprite: "bush6" },
    { x: 1500, y: 530, sprite: "bush3" },
    { x: 1480, y: 670, sprite: "bush4" },
    { x: 1520, y: 710, sprite: "bush2" }
  ];

  bushCoords.forEach(b => {
    const sp = SPRITES[b.sprite];
    bushes.push({
      x: b.x,
      y: b.y,
      spriteKey: b.sprite,
      radius: sp.colR,
      cut: false,
      regrowTimer: 0
    });
  });

  // River boundaries (crossable at bridge y: 540 to 670)
  obstacles.push({ type: "river_top", x: 1280, y: 0, w: 140, h: 540 });
  obstacles.push({ type: "river_bottom", x: 1280, y: 680, w: 140, h: 520 });

  // Cainos Village Props (props.png & shadow.png)
  // 1. Central Plaza
  propsList.push({ type: "cainos_prop", spriteKey: "statueMaiden", x: 540, y: 440, colR: 16 });
  propsList.push({ type: "cainos_prop", spriteKey: "benchFront", x: 460, y: 480, colW: 52, colH: 18 });
  propsList.push({ type: "cainos_prop", spriteKey: "benchFront", x: 620, y: 480, colW: 52, colH: 18 });
  propsList.push({ type: "cainos_prop", spriteKey: "magicCircle", x: 540, y: 600, decorative: true });
  propsList.push({ type: "cainos_prop", spriteKey: "signEast", x: 670, y: 530, colR: 8 });
  propsList.push({ type: "cainos_prop", spriteKey: "signWest", x: 410, y: 530, colR: 8 });

  // 2. Mayor Manor Props
  propsList.push({ type: "cainos_prop", spriteKey: "crateTall", x: 440, y: 375, colR: 15 });
  propsList.push({ type: "cainos_prop", spriteKey: "barrel", x: 400, y: 375, colR: 13 });

  // 3. Apothecary Props
  propsList.push({ type: "cainos_prop", spriteKey: "clayPot", x: 220, y: 550, colR: 10 });
  propsList.push({ type: "cainos_prop", spriteKey: "clayJug", x: 290, y: 550, colR: 9 });
  propsList.push({ type: "cainos_prop", spriteKey: "clayPotSmall", x: 310, y: 555, colR: 9 });

  // 4. Blacksmith Props
  propsList.push({ type: "cainos_prop", spriteKey: "barrel", x: 740, y: 430, colR: 13 });
  propsList.push({ type: "cainos_prop", spriteKey: "crateTall", x: 740, y: 475, colR: 15 });
  propsList.push({ type: "cainos_prop", spriteKey: "crateSmall", x: 740, y: 515, colR: 12 });

  // 5. Training Yard Props
  propsList.push({ type: "cainos_prop", spriteKey: "pillarRune", x: 770, y: 770, colR: 12 });
  propsList.push({ type: "cainos_prop", spriteKey: "chestClosed", x: 960, y: 770, colR: 14, isChest: true });

  // 6. Forest Boulders & Meadow
  propsList.push({ type: "cainos_prop", spriteKey: "boulder", x: 320, y: 220, colR: 22 });
  propsList.push({ type: "cainos_prop", spriteKey: "boulder", x: 1180, y: 360, colR: 22 });
  propsList.push({ type: "cainos_prop", spriteKey: "stonePile", x: 1220, y: 410, decorative: true });
  propsList.push({ type: "cainos_prop", spriteKey: "stoneSmall", x: 610, y: 640, decorative: true });
  propsList.push({ type: "cainos_prop", spriteKey: "stoneSmall", x: 490, y: 660, decorative: true });

  // Secret Chest across bridge
  propsList.push({ type: "cainos_prop", spriteKey: "chestClosed", x: 1580, y: 520, colR: 14, isChest: true, isSecret: true });

  // Register physical collisions for solid props
  propsList.forEach(p => {
    if (!p.decorative) {
      if (p.colR) {
        obstacles.push({ type: "prop_circle", x: p.x, y: p.y, radius: p.colR });
      } else if (p.colW) {
        obstacles.push({ type: "prop_rect", x: p.x - p.colW / 2, y: p.y - p.colH / 2, w: p.colW, h: p.colH });
      }
    }
  });

  // Exactly one basic slime enemy for the map (near training yard and east plaza)
  slimes.length = 0;
  slimes.push({
    x: 690,
    y: 600,
    radius: 18,
    hp: 45,
    maxHp: 45,
    speed: 55,
    vx: 0,
    vy: 0,
    color: "#52b788",
    eyeColor: "#1b4332",
    jumpTimer: 0,
    hitFlash: 0,
    isDefeated: false,
    deathTimer: 0,
    respawnTimer: 0
  });

  // Village NPCs
  npcs.push({
    name: "Elder Alistair",
    title: "Village Elder",
    x: 610,
    y: 530,
    radius: 16,
    robeColor: "#4361ee",
    hatColor: "#3a0ca3",
    speech: "Welcome to Oakhaven! Our newly restored stonework and ancient oak trees stand proud. Test your blade on the dummies, or explore beyond the stone bridge!"
  });

  npcs.push({
    name: "Brom Ironhide",
    title: "Master Blacksmith",
    x: 870,
    y: 470,
    radius: 16,
    robeColor: "#7f4f24",
    hatColor: "#362e2b",
    speech: "The anvil rings true! Use your Attack button to clear overgrown bushes and break into hidden chests. Dash to swiftly dodge threats!"
  });

  // Soft atmospheric cloud drifts
  clouds.length = 0;
  for (let i = 0; i < 6; i++) {
    clouds.push({
      x: Math.random() * WORLD_WIDTH,
      y: Math.random() * WORLD_HEIGHT,
      speed: 14 + Math.random() * 18,
      scale: 0.8 + Math.random() * 0.7,
      alpha: 0.12 + Math.random() * 0.08
    });
  }
}

buildCainosVillageMap();

// ------------------------------------------
// Camera System (Unchanged)
// ------------------------------------------
const camera = {
  x: player.x - VIRTUAL_WIDTH / 2,
  y: player.y - VIRTUAL_HEIGHT / 2,
  shake: 0,
  update: function(dt) {
    const targetX = player.x - VIRTUAL_WIDTH / 2;
    const targetY = player.y - VIRTUAL_HEIGHT / 2;
    this.x += (targetX - this.x) * 0.12;
    this.y += (targetY - this.y) * 0.12;

    this.x = Math.max(0, Math.min(WORLD_WIDTH - VIRTUAL_WIDTH, this.x));
    this.y = Math.max(0, Math.min(WORLD_HEIGHT - VIRTUAL_HEIGHT, this.y));

    if (this.shake > 0) {
      this.shake -= dt * 25;
      if (this.shake < 0) this.shake = 0;
    }
  }
};

// ------------------------------------------
// Multi-Touch & Input Handling (Unchanged)
// ------------------------------------------
function getCanvasPos(clientX, clientY) {
  const rect = canvas.getBoundingClientRect();
  const scaleX = VIRTUAL_WIDTH / rect.width;
  const scaleY = VIRTUAL_HEIGHT / rect.height;
  return {
    x: (clientX - rect.left) * scaleX,
    y: (clientY - rect.top) * scaleY
  };
}

function handleTouchStart(e) {
  initAudio();
  e.preventDefault();
  const touches = e.changedTouches;

  for (let i = 0; i < touches.length; i++) {
    const t = touches[i];
    const pos = getCanvasPos(t.clientX, t.clientY);

    // Status button (top right: VIRTUAL_WIDTH - 250, 20, 92, 36)
    if (pos.x >= VIRTUAL_WIDTH - 258 && pos.x <= VIRTUAL_WIDTH - 150 && pos.y >= 14 && pos.y <= 62) {
      toggleStatusWindow();
      continue;
    }

    // Sound toggle button (top right)
    if (pos.x >= VIRTUAL_WIDTH - 60 && pos.x <= VIRTUAL_WIDTH - 15 && pos.y >= 15 && pos.y <= 60) {
      soundEnabled = !soundEnabled;
      continue;
    }

    // Dismiss active dialogue
    if (activeDialogue) {
      activeDialogue = null;
      playSound("grass");
      continue;
    }

    // Status window clicks and stat point allocations
    if (isStatusWindowOpen) {
      if (handleStatusWindowClick(pos.x, pos.y)) {
        continue;
      }
    }

    // Attack Button (Bottom-Right)
    const distAttack = Math.hypot(pos.x - attackButton.x, pos.y - attackButton.y);
    if (distAttack <= attackButton.radius * 1.3) {
      attackButton.pressed = true;
      attackButton.touchId = t.identifier;
      triggerAttack();
      continue;
    }

    // Dash Button
    const distDash = Math.hypot(pos.x - dashButton.x, pos.y - dashButton.y);
    if (distDash <= dashButton.radius * 1.3) {
      dashButton.pressed = true;
      dashButton.touchId = t.identifier;
      triggerDash();
      continue;
    }

    // Talk / Interact Button
    const distInteract = Math.hypot(pos.x - interactButton.x, pos.y - interactButton.y);
    if (distInteract <= interactButton.radius * 1.3) {
      interactButton.pressed = true;
      interactButton.touchId = t.identifier;
      triggerInteract();
      continue;
    }

    // Virtual Joystick on left half of screen
    if (pos.x < VIRTUAL_WIDTH * 0.55 && !joystick.active) {
      joystick.active = true;
      joystick.touchId = t.identifier;
      const distToDefault = Math.hypot(pos.x - 130, pos.y - (VIRTUAL_HEIGHT - 120));
      if (distToDefault < 140) {
        joystick.baseX = 130;
        joystick.baseY = VIRTUAL_HEIGHT - 120;
      } else {
        joystick.baseX = pos.x;
        joystick.baseY = pos.y;
      }
      updateJoystick(pos.x, pos.y);
    }
  }
}

function handleTouchMove(e) {
  e.preventDefault();
  const touches = e.changedTouches;
  for (let i = 0; i < touches.length; i++) {
    const t = touches[i];
    if (joystick.active && t.identifier === joystick.touchId) {
      const pos = getCanvasPos(t.clientX, t.clientY);
      updateJoystick(pos.x, pos.y);
    }
  }
}

function handleTouchEnd(e) {
  e.preventDefault();
  const touches = e.changedTouches;
  for (let i = 0; i < touches.length; i++) {
    const t = touches[i];
    if (joystick.active && t.identifier === joystick.touchId) {
      resetJoystick();
    }
    if (attackButton.touchId === t.identifier) {
      attackButton.pressed = false;
      attackButton.touchId = null;
    }
    if (dashButton.touchId === t.identifier) {
      dashButton.pressed = false;
      dashButton.touchId = null;
    }
    if (interactButton.touchId === t.identifier) {
      interactButton.pressed = false;
      interactButton.touchId = null;
    }
  }
}

function updateJoystick(targetX, targetY) {
  const dx = targetX - joystick.baseX;
  const dy = targetY - joystick.baseY;
  const dist = Math.hypot(dx, dy);

  if (dist === 0) {
    joystick.currX = joystick.baseX;
    joystick.currY = joystick.baseY;
    joystick.dx = 0;
    joystick.dy = 0;
    joystick.force = 0;
  } else {
    const angle = Math.atan2(dy, dx);
    const clampedDist = Math.min(dist, joystick.radius);
    joystick.currX = joystick.baseX + Math.cos(angle) * clampedDist;
    joystick.currY = joystick.baseY + Math.sin(angle) * clampedDist;
    joystick.dx = Math.cos(angle);
    joystick.dy = Math.sin(angle);
    joystick.force = clampedDist / joystick.radius;
    joystick.angle = angle;
  }
}

function resetJoystick() {
  joystick.active = false;
  joystick.touchId = null;
  joystick.currX = joystick.baseX;
  joystick.currY = joystick.baseY;
  joystick.dx = 0;
  joystick.dy = 0;
  joystick.force = 0;
}

// Mouse controls for emulator
let mouseIsDown = false;
function handleMouseDown(e) {
  initAudio();
  mouseIsDown = true;
  const pos = getCanvasPos(e.clientX, e.clientY);

  // Status button (top right: VIRTUAL_WIDTH - 250, 20, 92, 36)
  if (pos.x >= VIRTUAL_WIDTH - 258 && pos.x <= VIRTUAL_WIDTH - 150 && pos.y >= 14 && pos.y <= 62) {
    toggleStatusWindow();
    return;
  }

  if (pos.x >= VIRTUAL_WIDTH - 60 && pos.x <= VIRTUAL_WIDTH - 15 && pos.y >= 15 && pos.y <= 60) {
    soundEnabled = !soundEnabled;
    return;
  }

  if (activeDialogue) {
    activeDialogue = null;
    playSound("grass");
    return;
  }

  // Status window clicks and stat point allocations
  if (isStatusWindowOpen) {
    if (handleStatusWindowClick(pos.x, pos.y)) {
      return;
    }
  }

  const distAttack = Math.hypot(pos.x - attackButton.x, pos.y - attackButton.y);
  if (distAttack <= attackButton.radius) {
    attackButton.pressed = true;
    triggerAttack();
    return;
  }

  const distDash = Math.hypot(pos.x - dashButton.x, pos.y - dashButton.y);
  if (distDash <= dashButton.radius) {
    dashButton.pressed = true;
    triggerDash();
    return;
  }

  const distInteract = Math.hypot(pos.x - interactButton.x, pos.y - interactButton.y);
  if (distInteract <= interactButton.radius) {
    interactButton.pressed = true;
    triggerInteract();
    return;
  }

  if (pos.x < VIRTUAL_WIDTH * 0.5) {
    joystick.active = true;
    joystick.baseX = 130;
    joystick.baseY = VIRTUAL_HEIGHT - 120;
    updateJoystick(pos.x, pos.y);
  }
}

function handleMouseMove(e) {
  if (mouseIsDown && joystick.active) {
    const pos = getCanvasPos(e.clientX, e.clientY);
    updateJoystick(pos.x, pos.y);
  }
}

function handleMouseUp(e) {
  mouseIsDown = false;
  resetJoystick();
  attackButton.pressed = false;
  dashButton.pressed = false;
  interactButton.pressed = false;
}

canvas.addEventListener("touchstart", handleTouchStart, { passive: false });
canvas.addEventListener("touchmove", handleTouchMove, { passive: false });
canvas.addEventListener("touchend", handleTouchEnd, { passive: false });
canvas.addEventListener("touchcancel", handleTouchEnd, { passive: false });

canvas.addEventListener("mousedown", handleMouseDown);
window.addEventListener("mousemove", handleMouseMove);
window.addEventListener("mouseup", handleMouseUp);

window.addEventListener("keydown", (e) => {
  initAudio();
  if (e.code === "KeyC") {
    toggleStatusWindow();
  }
  if (keys.hasOwnProperty(e.code)) {
    keys[e.code] = true;
    if (e.code === "Space" || e.code === "KeyJ") triggerAttack();
    if (e.code === "KeyK") triggerDash();
    if (e.code === "KeyE") triggerInteract();
  }
});

window.addEventListener("keyup", (e) => {
  if (keys.hasOwnProperty(e.code)) {
    keys[e.code] = false;
  }
});

// ------------------------------------------
// Combat & Interactions (Unchanged mechanics)
// ------------------------------------------
function triggerAttack() {
  if (player.isAttacking || player.attackCooldown > 0) return;

  player.isAttacking = true;
  player.attackProgress = 0;
  player.attackCooldown = 0.32;
  player.comboCount = (player.comboCount + 1) % 2;

  camera.shake = 3.5;
  playSound("swing");

  let reach = 48;
  let attackAngle = 0;
  if (player.facing === "right") attackAngle = 0;
  else if (player.facing === "down") attackAngle = Math.PI / 2;
  else if (player.facing === "left") attackAngle = Math.PI;
  else if (player.facing === "up") attackAngle = -Math.PI / 2;

  const hitX = player.x + Math.cos(attackAngle) * (reach * 0.7);
  const hitY = player.y + Math.sin(attackAngle) * (reach * 0.7);

  // Sparks
  for (let i = 0; i < 7; i++) {
    const sparkAngle = attackAngle - 0.6 + Math.random() * 1.2;
    const speed = 70 + Math.random() * 90;
    particles.push({
      x: hitX,
      y: hitY,
      vx: Math.cos(sparkAngle) * speed,
      vy: Math.sin(sparkAngle) * speed,
      life: 0.25 + Math.random() * 0.15,
      maxLife: 0.35,
      color: "#90e0ef",
      size: 3
    });
  }

  // Hit on Training Dummies
  dummies.forEach(d => {
    const dist = Math.hypot(hitX - d.x, hitY - d.y);
    if (dist < reach + d.radius) {
      d.wobble = 18 * (Math.random() > 0.5 ? 1 : -1);
      d.hitTime = 0.3;
      playSound("hit");
      camera.shake = 6;

      const dmg = 20 + Math.floor(Math.random() * 15);
      const isCrit = Math.random() > 0.65;
      const finalDmg = isCrit ? dmg * 2 : dmg;

      damageTexts.push({
        text: isCrit ? `CRIT! -${finalDmg}` : `-${finalDmg}`,
        x: d.x + (Math.random() * 16 - 8),
        y: d.y - 25,
        life: 0.7,
        color: isCrit ? "#ffb703" : "#ffffff",
        isCrit: isCrit
      });

      for (let k = 0; k < 6; k++) {
        particles.push({
          x: d.x,
          y: d.y,
          vx: (Math.random() - 0.5) * 140,
          vy: -60 - Math.random() * 80,
          life: 0.35,
          maxLife: 0.35,
          color: "#c2a679",
          size: 3
        });
      }
    }
  });

  // Hit on Cainos Bushes
  bushes.forEach(b => {
    if (b.cut) return;
    const dist = Math.hypot(hitX - b.x, hitY - b.y);
    if (dist < reach + b.radius) {
      b.cut = true;
      b.regrowTimer = 8;
      playSound("grass");

      for (let k = 0; k < 9; k++) {
        particles.push({
          x: b.x,
          y: b.y,
          vx: (Math.random() - 0.5) * 120,
          vy: -50 - Math.random() * 80,
          life: 0.4,
          maxLife: 0.4,
          color: "#52b788",
          size: 4
        });
      }

      if (Math.random() < 0.45) {
        player.gold += 5;
        playSound("coin");
        damageTexts.push({
          text: "+5 Gold!",
          x: b.x,
          y: b.y - 20,
          life: 0.7,
          color: "#ffd166"
        });
      }
    }
  });

  // Hit on Treasure Chests
  propsList.forEach(p => {
    if (p.isChest && p.spriteKey === "chestClosed") {
      const dist = Math.hypot(hitX - p.x, hitY - p.y);
      if (dist < reach + 20) {
        p.spriteKey = "chestOpen";
        playSound("coin");
        const reward = p.isSecret ? 50 : 25;
        player.gold += reward;
        damageTexts.push({
          text: `+${reward} GOLD! (Chest Opened)`,
          x: p.x,
          y: p.y - 25,
          life: 1.0,
          color: "#ffd166"
        });
      }
    }
  });

  // Hit on Slime enemy
  slimes.forEach(s => {
    if (s.isDefeated) return;
    const dist = Math.hypot(hitX - s.x, hitY - s.y);
    if (dist < reach + s.radius + 10) {
      // Slime damage scales directly with Knight's Attack stat
      const baseDmg = player.attack;
      const dmg = Math.round(baseDmg * (0.85 + Math.random() * 0.3));
      s.hp = Math.max(0, s.hp - dmg);
      s.hitFlash = 0.22;
      playSound("hit");
      camera.shake = 5;

      // Knockback in the direction of the Knight's strike
      const kbAngle = Math.atan2(s.y - player.y, s.x - player.x);
      s.vx = Math.cos(kbAngle) * 230;
      s.vy = Math.sin(kbAngle) * 230;

      damageTexts.push({
        text: `-${dmg}`,
        x: s.x,
        y: s.y - 20,
        life: 0.65,
        color: "#ff4d6d"
      });

      // Impact burst sparks
      for (let k = 0; k < 6; k++) {
        particles.push({
          x: s.x,
          y: s.y,
          vx: (Math.random() - 0.5) * 140,
          vy: (Math.random() - 0.5) * 140,
          life: 0.35,
          maxLife: 0.35,
          color: s.color,
          size: 3.5
        });
      }

      // Slime Defeat Behavior
      if (s.hp <= 0) {
        s.isDefeated = true;
        s.deathTimer = 0.5;
        s.respawnTimer = 4.0;
        player.gold += 20;
        playSound("coin");

        damageTexts.push({
          text: "+20 Gold! (Slime Defeated)",
          x: s.x,
          y: s.y - 32,
          life: 1.2,
          color: "#ffd166"
        });

        // Gain EXP on defeating enemy
        gainExp(25);

        // Splatter defeat particle explosion
        for (let k = 0; k < 18; k++) {
          const pAngle = Math.random() * Math.PI * 2;
          const pSpeed = 60 + Math.random() * 120;
          particles.push({
            x: s.x,
            y: s.y,
            vx: Math.cos(pAngle) * pSpeed,
            vy: Math.sin(pAngle) * pSpeed - 30,
            life: 0.45 + Math.random() * 0.2,
            maxLife: 0.65,
            color: Math.random() > 0.4 ? s.color : "#b7efc5",
            size: 3 + Math.random() * 3
          });
        }
      }
    }
  });
}

function triggerDash() {
  if (player.isDashing || player.dashCooldown > 0 || player.stamina < 20) return;

  player.stamina -= 25;
  player.isDashing = true;
  player.dashProgress = 0;
  player.dashCooldown = 0.7;

  let dashAngle = 0;
  if (player.moving && (joystick.dx !== 0 || joystick.dy !== 0)) {
    dashAngle = Math.atan2(joystick.dy, joystick.dx);
  } else {
    if (player.facing === "right") dashAngle = 0;
    else if (player.facing === "down") dashAngle = Math.PI / 2;
    else if (player.facing === "left") dashAngle = Math.PI;
    else if (player.facing === "up") dashAngle = -Math.PI / 2;
  }

  const dashSpeed = 460;
  player.dashVx = Math.cos(dashAngle) * dashSpeed;
  player.dashVy = Math.sin(dashAngle) * dashSpeed;

  playSound("dash");

  for (let i = 0; i < 8; i++) {
    particles.push({
      x: player.x,
      y: player.y + 10,
      vx: -player.dashVx * 0.2 + (Math.random() - 0.5) * 60,
      vy: -player.dashVy * 0.2 + (Math.random() - 0.5) * 60,
      life: 0.3,
      maxLife: 0.3,
      color: "#d8cbb5",
      size: 4
    });
  }
}

let activeDialogue = null;
function triggerInteract() {
  let closestNpc = null;
  let minDist = 90;

  npcs.forEach(n => {
    const dist = Math.hypot(player.x - n.x, player.y - n.y);
    if (dist < minDist) {
      closestNpc = n;
      minDist = dist;
    }
  });

  if (closestNpc) {
    activeDialogue = {
      name: closestNpc.name,
      title: closestNpc.title,
      text: closestNpc.speech
    };
    playSound("coin");
  } else {
    // Check well interaction
    const distWell = Math.hypot(player.x - 540, player.y - 530);
    if (distWell < 80) {
      player.hp = player.maxHp;
      playSound("coin");
      damageTexts.push({
        text: "Well Water: HP Fully Restored!",
        x: 540,
        y: 495,
        life: 1.0,
        color: "#52b788"
      });
    }
  }
}

// ------------------------------------------
// Collision Detection
// ------------------------------------------
function checkCollision(x, y, radius) {
  for (let i = 0; i < obstacles.length; i++) {
    const obs = obstacles[i];
    if (obs.type === "cainos_building" || obs.type === "cainos_wall" || obs.type === "river_top" || obs.type === "river_bottom" || obs.type === "prop_rect" || obs.w) {
      const nearestX = Math.max(obs.x, Math.min(x, obs.x + obs.w));
      const nearestY = Math.max(obs.y, Math.min(y, obs.y + obs.h));
      const dist = Math.hypot(x - nearestX, y - nearestY);
      if (dist < radius) return true;
    } else if (obs.type === "cainos_well" || obs.type === "cainos_tree" || obs.type === "prop_circle" || obs.radius) {
      const colRadius = obs.radius;
      const colY = obs.type === "cainos_tree" ? obs.y + 10 : obs.y;
      const dist = Math.hypot(x - obs.x, y - colY);
      if (dist < radius + colRadius) return true;
    }
  }
  return false;
}

// ------------------------------------------
// Update Loop
// ------------------------------------------
let lastTime = performance.now();

function update(dt) {
  if (player.stamina < player.maxStamina) {
    player.stamina = Math.min(player.maxStamina, player.stamina + dt * 25);
  }

  if (player.attackCooldown > 0) player.attackCooldown -= dt;
  if (player.dashCooldown > 0) player.dashCooldown -= dt;
  if (player.hurtTimer > 0) player.hurtTimer -= dt;

  if (player.isDashing) {
    player.dashProgress += dt / player.dashDuration;
    const moveX = player.dashVx * dt;
    const moveY = player.dashVy * dt;

    if (!checkCollision(player.x + moveX, player.y, player.radius)) player.x += moveX;
    if (!checkCollision(player.x, player.y + moveY, player.radius)) player.y += moveY;

    if (player.dashProgress >= 1) {
      player.isDashing = false;
    }
  } else {
    let inputX = 0;
    let inputY = 0;

    if (joystick.active && joystick.force > 0.1) {
      inputX = joystick.dx * joystick.force;
      inputY = joystick.dy * joystick.force;
    }

    if (keys.ArrowUp || keys.KeyW) inputY -= 1;
    if (keys.ArrowDown || keys.KeyS) inputY += 1;
    if (keys.ArrowLeft || keys.KeyA) inputX -= 1;
    if (keys.ArrowRight || keys.KeyD) inputX += 1;

    const inputLen = Math.hypot(inputX, inputY);
    if (inputLen > 0) {
      inputX /= inputLen;
      inputY /= inputLen;
      player.moving = true;

      if (Math.abs(inputX) > Math.abs(inputY)) {
        player.facing = inputX > 0 ? "right" : "left";
      } else {
        player.facing = inputY > 0 ? "down" : "up";
      }

      player.walkTimer += dt * 9;

      const speed = player.speed * (joystick.active ? Math.max(0.6, joystick.force) : 1);
      const stepX = inputX * speed * dt;
      const stepY = inputY * speed * dt;

      if (!checkCollision(player.x + stepX, player.y, player.radius)) {
        player.x += stepX;
      }
      if (!checkCollision(player.x, player.y + stepY, player.radius)) {
        player.y += stepY;
      }
    } else {
      player.moving = false;
      player.walkTimer = 0;
    }
  }

  if (player.isAttacking) {
    player.attackProgress += dt / player.attackDuration;
    if (player.attackProgress >= 1) {
      player.isAttacking = false;
    }
  }

  dummies.forEach(d => {
    if (d.wobble !== 0) {
      d.wobble *= 0.88;
      if (Math.abs(d.wobble) < 0.2) d.wobble = 0;
    }
    if (d.hitTime > 0) d.hitTime -= dt;
  });

  slimes.forEach(s => {
    // If defeated, handle death fade and respawn countdown
    if (s.isDefeated) {
      if (s.deathTimer > 0) s.deathTimer -= dt;
      if (s.respawnTimer > 0) {
        s.respawnTimer -= dt;
        if (s.respawnTimer <= 0) {
          s.isDefeated = false;
          s.hp = s.maxHp;
          s.deathTimer = 0;
          // Respawn in the open area near the training grounds
          s.x = 690 + (Math.random() - 0.5) * 60;
          s.y = 610 + (Math.random() - 0.5) * 60;
          s.vx = 0;
          s.vy = 0;

          // Respawn poof particles
          for (let k = 0; k < 10; k++) {
            particles.push({
              x: s.x,
              y: s.y,
              vx: (Math.random() - 0.5) * 80,
              vy: (Math.random() - 0.5) * 80,
              life: 0.35,
              maxLife: 0.35,
              color: "#52b788",
              size: 3
            });
          }
        }
      }
      return;
    }

    if (s.hitFlash > 0) s.hitFlash -= dt;

    // Dampen knockback velocity
    s.vx *= 0.88;
    s.vy *= 0.88;

    // Simple movement toward the Knight:
    // Every 1.1s, the slime gathers energy and hops directly toward the Knight's position
    s.jumpTimer += dt;
    const distToPlayer = Math.hypot(player.x - s.x, player.y - s.y);

    if (s.jumpTimer > 1.1) {
      s.jumpTimer = 0;
      if (distToPlayer > 28 && distToPlayer < 450) {
        const angle = Math.atan2(player.y - s.y, player.x - s.x);
        s.vx += Math.cos(angle) * 115;
        s.vy += Math.sin(angle) * 115;
      }
    } else if (distToPlayer > 26 && distToPlayer < 450) {
      // Gentle constant crawl towards the Knight between hops
      const angle = Math.atan2(player.y - s.y, player.x - s.x);
      const crawlSpeed = 22 * dt;
      const nextX = s.x + Math.cos(angle) * crawlSpeed;
      const nextY = s.y + Math.sin(angle) * crawlSpeed;
      if (!checkCollision(nextX, s.y, s.radius)) s.x = nextX;
      if (!checkCollision(s.x, nextY, s.radius)) s.y = nextY;
    }

    // Apply impulse velocity with map obstacle collision check
    if (!checkCollision(s.x + s.vx * dt, s.y, s.radius)) s.x += s.vx * dt;
    if (!checkCollision(s.x, s.y + s.vy * dt, s.radius)) s.y += s.vy * dt;

    // Contact damage to player (reduced by Defense)
    if (distToPlayer < player.radius + s.radius && player.hurtTimer <= 0 && !player.isDashing) {
      // Base damage 18, mitigated by Defense: minimum 3 damage
      const incomingDmg = Math.max(3, Math.round(18 * (100 / (100 + player.defense))));
      player.hp = Math.max(0, player.hp - incomingDmg);
      player.hurtTimer = 0.6;
      camera.shake = 6;
      playSound("hit");
      damageTexts.push({
        text: `-${incomingDmg} HP`,
        x: player.x,
        y: player.y - 25,
        life: 0.7,
        color: "#e63946"
      });
    }
  });

  bushes.forEach(b => {
    if (b.cut) {
      b.regrowTimer -= dt;
      if (b.regrowTimer <= 0) b.cut = false;
    }
  });

  for (let i = particles.length - 1; i >= 0; i--) {
    const p = particles[i];
    p.x += p.vx * dt;
    p.y += p.vy * dt;
    p.life -= dt;
    if (p.life <= 0) {
      particles.splice(i, 1);
    }
  }

  for (let i = damageTexts.length - 1; i >= 0; i--) {
    const dtItem = damageTexts[i];
    dtItem.y -= dt * 32;
    dtItem.life -= dt;
    if (dtItem.life <= 0) {
      damageTexts.splice(i, 1);
    }
  }

  clouds.forEach(c => {
    c.x += c.speed * dt;
    if (c.x > WORLD_WIDTH + 150) {
      c.x = -150;
      c.y = Math.random() * WORLD_HEIGHT;
    }
  });

  camera.update(dt);
}

// ------------------------------------------
// Cainos Map & Environment Rendering
// ------------------------------------------
function drawCainosMap() {
  // 1. Base Grassy Terrain from TX_Tileset_Grass pattern
  if (grassPattern) {
    ctx.fillStyle = grassPattern;
    ctx.fillRect(0, 0, WORLD_WIDTH, WORLD_HEIGHT);
  } else {
    ctx.fillStyle = "#5c7d24";
    ctx.fillRect(0, 0, WORLD_WIDTH, WORLD_HEIGHT);
  }

  // 2. Wildflower Clumps & Grass Tufts across meadows
  if (ASSETS.grass && ASSETS.grass.naturalWidth > 0) {
    // Draw clover & flowers from top-right of TX_Tileset_Grass (128, 0, 128, 128)
    const flowerSpots = [
      { x: 100, y: 100 }, { x: 300, y: 80 }, { x: 700, y: 120 },
      { x: 950, y: 140 }, { x: 200, y: 850 }, { x: 450, y: 920 },
      { x: 650, y: 960 }, { x: 1100, y: 240 }, { x: 1450, y: 220 },
      { x: 1550, y: 400 }, { x: 1480, y: 780 }, { x: 1620, y: 920 }
    ];
    flowerSpots.forEach(s => {
      ctx.drawImage(ASSETS.grass, 128, 0, 128, 128, s.x, s.y, 128, 128);
    });
  }

  // 3. Central Village Plaza (Stone Ground from TX_Tileset_Stone_Ground)
  drawVillagePlaza();

  // 4. Cobblestone Pathways connecting the village
  drawCainosPaths();

  // 5. River & Stone Bridge
  drawRiverAndBridge();

  // 6. Training Grounds Walls
  drawTrainingWalls();

  // 7. Cuttable Bushes (Base / cut state)
  bushes.forEach(b => {
    if (b.cut) {
      ctx.fillStyle = "#3d4b1a";
      ctx.beginPath();
      ctx.arc(b.x, b.y, 6, 0, Math.PI * 2);
      ctx.fill();
    }
  });
}

function drawVillagePlaza() {
  const plazaX = 400;
  const plazaY = 400;
  const plazaW = 280;
  const plazaH = 260;

  if (stonePlazaPattern) {
    ctx.fillStyle = stonePlazaPattern;
    ctx.fillRect(plazaX, plazaY, plazaW, plazaH);
  } else {
    ctx.fillStyle = "#8a867c";
    ctx.fillRect(plazaX, plazaY, plazaW, plazaH);
  }

  // Outer Stone Edges from TX_Tileset_Stone_Ground
  if (ASSETS.stoneGround && ASSETS.stoneGround.naturalWidth > 0) {
    // Border top and bottom
    for (let px = plazaX; px < plazaX + plazaW; px += 32) {
      ctx.drawImage(ASSETS.stoneGround, 0, 0, 32, 16, px, plazaY - 8, 32, 16);
      ctx.drawImage(ASSETS.stoneGround, 0, 112, 32, 16, px, plazaY + plazaH - 8, 32, 16);
    }
  }
}

function drawCainosPaths() {
  if (!ASSETS.grass || ASSETS.grass.naturalWidth === 0) return;

  // Paths from TX_Tileset_Grass cobblestone tiles
  // Source tile: (0, 128, 112, 128) contains stone slabs on grass
  drawPathSegment(250, 530, 400, 530, 48); // Apothecary to Plaza
  drawPathSegment(540, 350, 540, 400, 52); // Mayor to Plaza
  drawPathSegment(680, 510, 780, 470, 48); // Plaza to Smithy
  drawPathSegment(540, 660, 840, 730, 48); // Plaza to Training Grounds
  drawPathSegment(680, 540, 1280, 600, 52); // Plaza to Stone Bridge
  drawPathSegment(1420, 600, 1650, 600, 44); // Stone Bridge to Meadow
}

function drawPathSegment(x1, y1, x2, y2, width) {
  // Tile cobblestone textures along line
  const dist = Math.hypot(x2 - x1, y2 - y1);
  const angle = Math.atan2(y2 - y1, x2 - x1);
  const step = 32;

  ctx.save();
  for (let d = 0; d < dist; d += step) {
    const curX = x1 + Math.cos(angle) * d;
    const curY = y1 + Math.sin(angle) * d;
    // Cobblestone tile from TX_Tileset_Grass (0, 128, 32, 32)
    ctx.drawImage(ASSETS.grass, 0, 128, 48, 48, curX - width / 2, curY - width / 2, width, width);
  }
  ctx.restore();
}

function drawRiverAndBridge() {
  const riverX = 1280;
  const riverW = 140;

  // River water gradient
  const grad = ctx.createLinearGradient(riverX, 0, riverX + riverW, 0);
  grad.addColorStop(0, "#0077b6");
  grad.addColorStop(0.5, "#0096c7");
  grad.addColorStop(1, "#023e8a");
  ctx.fillStyle = grad;
  ctx.fillRect(riverX, 0, riverW, WORLD_HEIGHT);

  // River banks with stone pavers
  if (ASSETS.stoneGround && ASSETS.stoneGround.naturalWidth > 0) {
    for (let py = 0; py < WORLD_HEIGHT; py += 32) {
      if (py >= 530 && py <= 670) continue;
      ctx.drawImage(ASSETS.stoneGround, 112, 0, 16, 32, riverX - 12, py, 12, 32);
      ctx.drawImage(ASSETS.stoneGround, 0, 0, 16, 32, riverX + riverW, py, 12, 32);
    }
  }

  // Water ripples
  const waveTime = performance.now() * 0.002;
  ctx.strokeStyle = "rgba(255, 255, 255, 0.35)";
  ctx.lineWidth = 2;
  for (let y = 30; y < WORLD_HEIGHT; y += 75) {
    if (y > 520 && y < 690) continue;
    const waveX = riverX + 25 + Math.sin(waveTime + y) * 16;
    ctx.beginPath();
    ctx.moveTo(waveX, y);
    ctx.lineTo(waveX + 35, y);
    ctx.stroke();
  }

  // Stone Bridge Crossing (from TX_Struct ef29e2c1.png)
  const bridgeX = 1260;
  const bridgeY = 540;
  const bridgeW = 180;
  const bridgeH = 140;

  // Bridge Shadow
  ctx.fillStyle = "rgba(0,0,0,0.4)";
  ctx.fillRect(bridgeX - 4, bridgeY + 8, bridgeW + 8, bridgeH);

  if (ASSETS.struct && ASSETS.struct.naturalWidth > 0) {
    // Draw Stone Bridge Slabs & Arch
    for (let py = bridgeY; py < bridgeY + bridgeH; py += 48) {
      ctx.drawImage(ASSETS.struct, 32, 32, 64, 48, bridgeX, py, bridgeW, 48);
    }
    // Stone railings
    ctx.drawImage(ASSETS.struct, 408, 26, 80, 24, bridgeX, bridgeY - 12, bridgeW, 20);
    ctx.drawImage(ASSETS.struct, 408, 66, 80, 24, bridgeX, bridgeY + bridgeH - 8, bridgeW, 20);
  } else {
    ctx.fillStyle = "#7f5539";
    ctx.fillRect(bridgeX, bridgeY, bridgeW, bridgeH);
  }
}

function drawTrainingWalls() {
  // Stone walls around training yard using TX_Tileset_Wall
  obstacles.forEach(o => {
    if (o.type === "cainos_wall") {
      if (ASSETS.wall && ASSETS.wall.naturalWidth > 0) {
        if (o.w > o.h) {
          // Horizontal wall
          for (let px = o.x; px < o.x + o.w; px += 64) {
            ctx.drawImage(ASSETS.wall, 32, 192, 64, 32, px, o.y - 16, Math.min(64, o.x + o.w - px), 32);
          }
        } else {
          // Vertical wall
          for (let py = o.y; py < o.y + o.h; py += 32) {
            ctx.drawImage(ASSETS.wall, 32, 288, 32, 32, o.x - 8, py, 32, Math.min(32, o.y + o.h - py));
          }
        }
      } else {
        ctx.fillStyle = "#6c757d";
        ctx.fillRect(o.x, o.y, o.w, o.h);
      }
    }
  });
}

// ------------------------------------------
// Y-Sorted Entity & Structure Rendering
// ------------------------------------------
function drawCainosEntities() {
  const renderList = [];

  // 1. Cainos Buildings
  obstacles.forEach(o => {
    if (o.type === "cainos_building") {
      renderList.push({ type: "cainos_building", y: o.y + o.h, obj: o });
    }
  });

  // 2. Cainos Trees (plant.png)
  obstacles.forEach(o => {
    if (o.type === "cainos_tree") {
      renderList.push({ type: "cainos_tree", y: o.y + 10, obj: o });
    }
  });

  // 3. Cainos Props (props.png)
  propsList.forEach(p => {
    renderList.push({ type: "cainos_prop", y: p.y, obj: p });
  });

  // 4. Cainos Well
  obstacles.forEach(o => {
    if (o.type === "cainos_well") {
      renderList.push({ type: "cainos_well", y: o.y, obj: o });
    }
  });

  // 5. Cainos Bushes (only if not cut)
  bushes.forEach(b => {
    if (!b.cut) {
      renderList.push({ type: "cainos_bush", y: b.y, obj: b });
    }
  });

  // 6. Training Dummies
  dummies.forEach(d => {
    renderList.push({ type: "dummy", y: d.y, obj: d });
  });

  // 7. NPCs
  npcs.forEach(n => {
    renderList.push({ type: "npc", y: n.y, obj: n });
  });

  // 8. Slimes
  slimes.forEach(s => {
    renderList.push({ type: "slime", y: s.y, obj: s });
  });

  // 9. Player (Kept exactly as requested)
  renderList.push({ type: "player", y: player.y, obj: player });

  // Sort by Y position for depth
  renderList.sort((a, b) => a.y - b.y);

  // A. First render cast shadows on the ground
  ctx.save();
  ctx.globalAlpha = 0.5;
  renderList.forEach(item => {
    if (item.type === "cainos_tree") {
      drawTreeShadow(item.obj);
    } else if (item.type === "cainos_bush") {
      drawBushShadow(item.obj);
    } else if (item.type === "cainos_prop") {
      drawPropShadow(item.obj);
    } else if (item.type === "cainos_well") {
      drawWellShadow(item.obj);
    }
  });
  ctx.restore();

  // B. Render the sorted entities
  renderList.forEach(item => {
    if (item.type === "cainos_building") drawCainosBuilding(item.obj);
    else if (item.type === "cainos_tree") drawCainosTree(item.obj);
    else if (item.type === "cainos_bush") drawCainosBush(item.obj);
    else if (item.type === "cainos_prop") drawCainosProp(item.obj);
    else if (item.type === "cainos_well") drawCainosWell(item.obj);
    else if (item.type === "dummy") drawDummy(item.obj);
    else if (item.type === "npc") drawNpc(item.obj);
    else if (item.type === "slime") drawSlime(item.obj);
    else if (item.type === "player") drawPlayer();
  });
}

// ------------------------------------------
// Cainos Sprite Drawing Functions
// ------------------------------------------
function drawTreeShadow(t) {
  if (!ASSETS.plantShadow || ASSETS.plantShadow.naturalWidth === 0) return;
  const sp = SPRITES[t.spriteKey];
  ctx.drawImage(
    ASSETS.plantShadow,
    sp.x, sp.y, sp.w, sp.h,
    t.x - sp.anchorX, t.y - sp.anchorY, sp.w, sp.h
  );
}

function drawCainosTree(t) {
  if (!ASSETS.plant || ASSETS.plant.naturalWidth === 0) return;
  const sp = SPRITES[t.spriteKey];
  ctx.drawImage(
    ASSETS.plant,
    sp.x, sp.y, sp.w, sp.h,
    t.x - sp.anchorX, t.y - sp.anchorY, sp.w, sp.h
  );
}

function drawBushShadow(b) {
  if (!ASSETS.plantShadow || ASSETS.plantShadow.naturalWidth === 0) return;
  const sp = SPRITES[b.spriteKey];
  ctx.drawImage(
    ASSETS.plantShadow,
    sp.x, sp.y, sp.w, sp.h,
    b.x - sp.anchorX, b.y - sp.anchorY, sp.w, sp.h
  );
}

function drawCainosBush(b) {
  if (!ASSETS.plant || ASSETS.plant.naturalWidth === 0) return;
  const sp = SPRITES[b.spriteKey];
  ctx.drawImage(
    ASSETS.plant,
    sp.x, sp.y, sp.w, sp.h,
    b.x - sp.anchorX, b.y - sp.anchorY, sp.w, sp.h
  );
}

function drawPropShadow(p) {
  if (!ASSETS.propsShadow || ASSETS.propsShadow.naturalWidth === 0) return;
  const sp = SPRITES[p.spriteKey];
  if (!sp) return;
  ctx.drawImage(
    ASSETS.propsShadow,
    sp.x, sp.y, sp.w, sp.h,
    p.x - sp.anchorX, p.y - sp.anchorY, sp.w, sp.h
  );
}

function drawCainosProp(p) {
  if (!ASSETS.props || ASSETS.props.naturalWidth === 0) return;
  const sp = SPRITES[p.spriteKey];
  if (!sp) return;

  // Draw Magic Circle with pulsating cyan glow
  if (p.spriteKey === "magicCircle") {
    const pulse = 0.65 + Math.sin(performance.now() * 0.003) * 0.35;
    ctx.save();
    ctx.shadowColor = "#48cae4";
    ctx.shadowBlur = 12 * pulse;
    ctx.drawImage(
      ASSETS.props,
      sp.x, sp.y, sp.w, sp.h,
      p.x - sp.anchorX, p.y - sp.anchorY, sp.w, sp.h
    );
    ctx.restore();
    return;
  }

  // Draw Standard Cainos Prop
  ctx.drawImage(
    ASSETS.props,
    sp.x, sp.y, sp.w, sp.h,
    p.x - sp.anchorX, p.y - sp.anchorY, sp.w, sp.h
  );
}

function drawWellShadow(w) {
  if (!ASSETS.propsShadow || ASSETS.propsShadow.naturalWidth === 0) return;
  const sp = SPRITES.well;
  ctx.drawImage(
    ASSETS.propsShadow,
    sp.x, sp.y, sp.w, sp.h,
    w.x - sp.anchorX, w.y - sp.anchorY, sp.w, sp.h
  );
}

function drawCainosWell(w) {
  if (!ASSETS.props || ASSETS.props.naturalWidth === 0) return;
  const sp = SPRITES.well;

  // Draw the Cainos stone well
  ctx.drawImage(
    ASSETS.props,
    sp.x, sp.y, sp.w, sp.h,
    w.x - sp.anchorX, w.y - sp.anchorY, sp.w, sp.h
  );

  // Animated Water Ripple in well center
  const rip = (performance.now() * 0.003) % 1;
  ctx.strokeStyle = "rgba(72, 202, 228, 0.6)";
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.arc(w.x, w.y + 4, 3 + rip * 12, 0, Math.PI * 2);
  ctx.stroke();
}

function drawCainosBuilding(b) {
  // Building Ground Shadow
  ctx.fillStyle = "rgba(0,0,0,0.35)";
  ctx.fillRect(b.x + 8, b.y + b.h - 8, b.w + 16, 26);

  if (ASSETS.wall && ASSETS.wall.naturalWidth > 0) {
    // 1. Stone Ashlar Walls from TX_Tileset_Wall (32, 32, 128, 128)
    const wallH = b.h - 40;
    for (let px = b.x; px < b.x + b.w; px += 64) {
      const sliceW = Math.min(64, b.x + b.w - px);
      ctx.drawImage(ASSETS.wall, 32, 32, sliceW, wallH, px, b.y + 40, sliceW, wallH);
    }

    // Window segment
    ctx.drawImage(ASSETS.wall, 192, 192, 32, 64, b.x + 36, b.y + 60, 32, 64);

    // 2. Wooden Arched Door from TX_Props (29, 103, 37, 50)
    if (ASSETS.props && ASSETS.props.naturalWidth > 0) {
      ctx.drawImage(ASSETS.props, 29, 103, 37, 50, b.doorX, b.y + b.h - 50, 37, 50);
    }

    // 3. Roof with decorative slope and eaves
    ctx.fillStyle = b.roofHue;
    ctx.beginPath();
    ctx.moveTo(b.x - 16, b.y + 46);
    ctx.lineTo(b.x + b.w / 2, b.y - 18);
    ctx.lineTo(b.x + b.w + 16, b.y + 46);
    ctx.closePath();
    ctx.fill();

    ctx.strokeStyle = "#251d18";
    ctx.lineWidth = 3;
    ctx.stroke();

    // 4. Stone Chimney with smoke
    const chimX = b.x + b.w - 38;
    const chimY = b.y - 8;
    ctx.drawImage(ASSETS.wall, 32, 288, 24, 32, chimX, chimY - 24, 24, 32);

    const time = performance.now() * 0.001;
    ctx.fillStyle = "rgba(220, 220, 220, 0.45)";
    for (let s = 0; s < 3; s++) {
      const puffY = chimY - 30 - ((time * 24 + s * 24) % 65);
      const puffX = chimX + 12 + Math.sin(puffY * 0.1) * 8;
      const puffRadius = 6 + (chimY - puffY) * 0.16;
      ctx.beginPath();
      ctx.arc(puffX, puffY, puffRadius, 0, Math.PI * 2);
      ctx.fill();
    }

    // Blacksmith Forge Special Embers
    if (b.isSmithy) {
      const flameFlicker = Math.sin(performance.now() * 0.01) * 3;
      ctx.fillStyle = "#f77f00";
      ctx.beginPath();
      ctx.arc(b.x + 75, b.y + 75, 14 + flameFlicker, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#fcbf49";
      ctx.beginPath();
      ctx.arc(b.x + 75, b.y + 75, 7, 0, Math.PI * 2);
      ctx.fill();
    }
  } else {
    // Fallback if textures loading
    ctx.fillStyle = "#8a867c";
    ctx.fillRect(b.x, b.y + 40, b.w, b.h - 40);
  }

  // Name Sign Banner
  ctx.fillStyle = "#ffffff";
  ctx.font = "bold 12px sans-serif";
  ctx.textAlign = "center";
  ctx.shadowColor = "#000000";
  ctx.shadowBlur = 4;
  ctx.fillText(b.name, b.x + b.w / 2, b.y + 34);
  ctx.shadowBlur = 0;
}

// ------------------------------------------
// NPCs, Dummy, Slimes, and Player Character
// (All unchanged as requested)
// ------------------------------------------
function drawDummy(d) {
  ctx.fillStyle = "rgba(0, 0, 0, 0.25)";
  ctx.beginPath();
  ctx.ellipse(d.x, d.y + 14, 20, 8, 0, 0, Math.PI * 2);
  ctx.fill();

  ctx.save();
  ctx.translate(d.x, d.y + 10);
  ctx.rotate((d.wobble * Math.PI) / 180);

  ctx.fillStyle = "#7f5539";
  ctx.fillRect(-5, -38, 10, 42);
  ctx.fillRect(-24, -30, 48, 8);

  ctx.fillStyle = d.hitTime > 0 ? "#ff4d6d" : "#e9c46a";
  ctx.beginPath();
  ctx.ellipse(0, -26, 16, 18, 0, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "#e63946";
  ctx.beginPath();
  ctx.arc(0, -26, 7, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "#ffffff";
  ctx.beginPath();
  ctx.arc(0, -26, 3, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "#f4a261";
  ctx.beginPath();
  ctx.arc(0, -48, 11, 0, Math.PI * 2);
  ctx.fill();

  ctx.restore();
}

function drawNpc(n) {
  ctx.fillStyle = "rgba(0,0,0,0.25)";
  ctx.beginPath();
  ctx.ellipse(n.x, n.y + 10, 16, 7, 0, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = n.robeColor;
  ctx.beginPath();
  ctx.ellipse(n.x, n.y, 14, 16, 0, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "#fcd5ce";
  ctx.beginPath();
  ctx.arc(n.x, n.y - 14, 9, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "#e9ecef";
  ctx.beginPath();
  ctx.moveTo(n.x - 7, n.y - 12);
  ctx.lineTo(n.x, n.y - 2);
  ctx.lineTo(n.x + 7, n.y - 12);
  ctx.closePath();
  ctx.fill();

  ctx.fillStyle = n.hatColor;
  ctx.beginPath();
  ctx.ellipse(n.x, n.y - 20, 15, 5, 0, 0, Math.PI * 2);
  ctx.fill();

  ctx.beginPath();
  ctx.moveTo(n.x - 10, n.y - 20);
  ctx.lineTo(n.x + 4, n.y - 42);
  ctx.lineTo(n.x + 10, n.y - 20);
  ctx.closePath();
  ctx.fill();

  const bob = Math.sin(performance.now() * 0.005) * 4;
  ctx.fillStyle = "#ffd166";
  ctx.beginPath();
  ctx.arc(n.x, n.y - 50 + bob, 10, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#1b4332";
  ctx.font = "bold 11px sans-serif";
  ctx.textAlign = "center";
  ctx.fillText("!", n.x, n.y - 46 + bob);

  ctx.fillStyle = "#ffffff";
  ctx.font = "bold 10px sans-serif";
  ctx.fillText(n.name, n.x, n.y + 22);
}

function drawSlime(s) {
  // If defeated and past death fade, don't draw until respawn
  if (s.isDefeated && s.deathTimer <= 0) return;

  ctx.save();
  if (s.isDefeated) {
    const fade = Math.max(0, s.deathTimer / 0.5);
    ctx.globalAlpha = fade;
  }

  // Slime ground shadow
  ctx.fillStyle = "rgba(0,0,0,0.25)";
  ctx.beginPath();
  ctx.ellipse(s.x, s.y + 11, s.radius * 1.05, s.radius * 0.42, 0, 0, Math.PI * 2);
  ctx.fill();

  const bounce = Math.abs(Math.sin(performance.now() * 0.006 + s.jumpTimer * 3.5));
  let scaleY = 1 - bounce * 0.28;
  let scaleX = 1 + bounce * 0.22;

  // Squish into a puddle when defeated
  if (s.isDefeated) {
    scaleY = Math.max(0.15, s.deathTimer);
    scaleX = 1.4;
  }

  ctx.translate(s.x, s.y + 5);
  ctx.scale(scaleX, scaleY);

  // Slime Gel Body
  ctx.fillStyle = s.hitFlash > 0 ? "#ffffff" : s.color;
  ctx.beginPath();
  ctx.arc(0, -s.radius * 0.6, s.radius, Math.PI, 0);
  ctx.bezierCurveTo(s.radius, 0, -s.radius, 0, -s.radius, -s.radius * 0.6);
  ctx.closePath();
  ctx.fill();

  // Highlight bubble reflection
  if (!s.isDefeated && s.hitFlash <= 0) {
    ctx.fillStyle = "rgba(255, 255, 255, 0.45)";
    ctx.beginPath();
    ctx.ellipse(-s.radius * 0.35, -s.radius * 0.9, s.radius * 0.35, s.radius * 0.18, -Math.PI / 6, 0, Math.PI * 2);
    ctx.fill();
  }

  // Cute Slime Eyes
  ctx.fillStyle = s.eyeColor;
  ctx.beginPath();
  ctx.arc(-5, -s.radius * 0.65, 3.2, 0, Math.PI * 2);
  ctx.arc(5, -s.radius * 0.65, 3.2, 0, Math.PI * 2);
  ctx.fill();

  // Eye shines
  ctx.fillStyle = "#ffffff";
  ctx.beginPath();
  ctx.arc(-4, -s.radius * 0.72, 1.2, 0, Math.PI * 2);
  ctx.arc(6, -s.radius * 0.72, 1.2, 0, Math.PI * 2);
  ctx.fill();

  ctx.restore();

  // Enemy Health Bar (Visible above the Slime)
  if (!s.isDefeated) {
    const barW = 32;
    const barH = 5;
    const barX = s.x - barW / 2;
    const barY = s.y - s.radius - 14;

    // Dark border & background
    ctx.fillStyle = "rgba(15, 23, 42, 0.85)";
    ctx.fillRect(barX - 1, barY - 1, barW + 2, barH + 2);
    ctx.fillStyle = "rgba(40, 10, 10, 0.8)";
    ctx.fillRect(barX, barY, barW, barH);

    // Dynamic red-to-coral HP fill
    const hpRatio = Math.max(0, s.hp / s.maxHp);
    ctx.fillStyle = s.hp > s.maxHp * 0.3 ? "#ef233c" : "#ff0054";
    ctx.fillRect(barX, barY, barW * hpRatio, barH);

    // HP label
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 8px sans-serif";
    ctx.textAlign = "center";
    ctx.shadowColor = "#000000";
    ctx.shadowBlur = 3;
    ctx.fillText("SLIME", s.x, barY - 3);
    ctx.shadowBlur = 0;
  }
}

function drawPlayer() {
  const p = player;

  // Ground shadow oval under the Knight
  ctx.fillStyle = "rgba(0, 0, 0, 0.35)";
  ctx.beginPath();
  ctx.ellipse(p.x, p.y + 2, 16, 7, 0, 0, Math.PI * 2);
  ctx.fill();

  // Hurt flash effect (blink when invulnerable/hurt)
  if (p.hurtTimer > 0 && Math.floor(performance.now() / 60) % 2 === 0) {
    ctx.globalAlpha = 0.45;
  }

  // Dash ghost / speed trail
  if (p.isDashing) {
    ctx.globalAlpha = 0.75;
    ctx.fillStyle = "rgba(72, 202, 228, 0.4)";
    ctx.beginPath();
    ctx.ellipse(p.x - p.dashVx * 0.06, p.y + 2 - p.dashVy * 0.06, 18, 8, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  // Determine Knight frame index from attack pose, 4-direction walking cycle, or idle
  // Turnaround frames:
  // 0: south, 1: south-east, 2: east, 3: north-east, 4: north, 5: north-west, 6: west, 7: south-west
  let frameIndex = 0;
  let walkBob = 0;
  let attackLungeX = 0;
  let attackLungeY = 0;

  if (p.isAttacking) {
    // Reuse directional sprites to create a 3-phase attack motion:
    // Phase 1 (0.00 - 0.25): Windup / recoil
    // Phase 2 (0.25 - 0.70): Forward slash / strike
    // Phase 3 (0.70 - 1.00): Follow-through / recovery
    const prog = p.attackProgress;
    const lungeDist = Math.sin(prog * Math.PI) * 7;

    if (p.facing === "down") {
      attackLungeY = lungeDist;
      if (prog < 0.25) {
        frameIndex = 7; // slight windup angle (south-west)
      } else if (prog < 0.70) {
        frameIndex = 0; // forward strike (south)
      } else {
        frameIndex = 1; // follow-through angle (south-east)
      }
    } else if (p.facing === "up") {
      attackLungeY = -lungeDist;
      if (prog < 0.25) {
        frameIndex = 3; // slight windup angle (north-east)
      } else if (prog < 0.70) {
        frameIndex = 4; // forward strike (north)
      } else {
        frameIndex = 5; // follow-through angle (north-west)
      }
    } else if (p.facing === "right") {
      attackLungeX = lungeDist;
      if (prog < 0.25) {
        frameIndex = 3; // windup tilted back (north-east)
      } else if (prog < 0.70) {
        frameIndex = 2; // direct slash (east)
      } else {
        frameIndex = 1; // follow-through cut (south-east)
      }
    } else if (p.facing === "left") {
      attackLungeX = -lungeDist;
      if (prog < 0.25) {
        frameIndex = 5; // windup tilted back (north-west)
      } else if (prog < 0.70) {
        frameIndex = 6; // direct slash (west)
      } else {
        frameIndex = 7; // follow-through cut (south-west)
      }
    }
  } else if (p.moving) {
    // 4-step walk cycle using the turnaround diagonal frames for dynamic leg steps:
    // Step 0: step left, Step 1: contact/pass, Step 2: step right, Step 3: contact/pass
    const cycleStep = Math.floor((p.walkTimer * 5.5) % 4);
    walkBob = Math.abs(Math.sin(p.walkTimer * 5.5)) * 2.2;

    if (p.facing === "down") {
      // 0: south, 7: south-west step, 1: south-east step
      if (cycleStep === 0) frameIndex = 7;
      else if (cycleStep === 1) frameIndex = 0;
      else if (cycleStep === 2) frameIndex = 1;
      else frameIndex = 0;
    } else if (p.facing === "up") {
      // 4: north, 5: north-west step, 3: north-east step
      if (cycleStep === 0) frameIndex = 5;
      else if (cycleStep === 1) frameIndex = 4;
      else if (cycleStep === 2) frameIndex = 3;
      else frameIndex = 4;
    } else if (p.facing === "right") {
      // 2: east, 1: south-east step, 3: north-east step
      if (cycleStep === 0) frameIndex = 1;
      else if (cycleStep === 1) frameIndex = 2;
      else if (cycleStep === 2) frameIndex = 3;
      else frameIndex = 2;
    } else if (p.facing === "left") {
      // 6: west, 7: south-west step, 5: north-west step
      if (cycleStep === 0) frameIndex = 7;
      else if (cycleStep === 1) frameIndex = 6;
      else if (cycleStep === 2) frameIndex = 5;
      else frameIndex = 6;
    }
  } else {
    // Idle cardinal directions with subtle breathing bob
    walkBob = Math.sin(performance.now() / 380) * 0.8;
    if (p.facing === "down") frameIndex = 0;
    else if (p.facing === "up") frameIndex = 4;
    else if (p.facing === "right") frameIndex = 2;
    else if (p.facing === "left") frameIndex = 6;
  }

  // Draw Knight Sprite
  const knightImg = ASSETS.knightTurnaround;
  if (knightImg && knightImg.complete && knightImg.naturalWidth > 0) {
    const sx = frameIndex * 64;
    const sy = 0;
    const sw = 64;
    const sh = 64;
    // Pivot is [32, 56], placing the Knight's feet naturally at p.x + attackLungeX, p.y + attackLungeY
    const dx = Math.round(p.x + attackLungeX - 32);
    const dy = Math.round(p.y + attackLungeY - 56 - walkBob);

    ctx.drawImage(knightImg, sx, sy, sw, sh, dx, dy, 64, 64);
  } else {
    // Fallback if image not ready
    ctx.fillStyle = "#3a86ff";
    ctx.beginPath();
    ctx.arc(p.x + attackLungeX, p.y + attackLungeY - 18 - walkBob, 14, 0, Math.PI * 2);
    ctx.fill();
  }

  // Attack slash effect & weapon swing
  drawSwordAndSlash(p, walkBob, attackLungeX, attackLungeY);
  ctx.globalAlpha = 1.0;
}

function drawSwordAndSlash(p, walkBob, lungeX = 0, lungeY = 0) {
  let baseAngle = 0;
  let pivotOffsetX = 0;
  let pivotOffsetY = -22;

  // Align sword pivot relative to the Knight's hand/body according to facing direction
  if (p.facing === "right") {
    baseAngle = 0;
    pivotOffsetX = 10;
    pivotOffsetY = -22;
  } else if (p.facing === "down") {
    baseAngle = Math.PI / 2;
    pivotOffsetX = 8;
    pivotOffsetY = -18;
  } else if (p.facing === "left") {
    baseAngle = Math.PI;
    pivotOffsetX = -10;
    pivotOffsetY = -22;
  } else if (p.facing === "up") {
    baseAngle = -Math.PI / 2;
    pivotOffsetX = -8;
    pivotOffsetY = -24;
  }

  if (p.isAttacking) {
    const progress = p.attackProgress;
    // Generous 160-degree slash arc centered on the Knight's current facing direction
    const sweepRange = Math.PI * 0.9;
    const startAngle = baseAngle - sweepRange / 2;
    const currentAngle = startAngle + sweepRange * progress;

    ctx.save();
    ctx.translate(p.x + lungeX + pivotOffsetX, p.y + lungeY + pivotOffsetY - walkBob);

    // 1. Semi-transparent cyan slash crescent fan / motion blur
    ctx.beginPath();
    ctx.arc(0, 0, 48, startAngle, currentAngle, false);
    ctx.strokeStyle = "rgba(0, 180, 216, 0.4)";
    ctx.lineWidth = 22;
    ctx.lineCap = "round";
    ctx.stroke();

    // 2. Bright glowing electric blue blade trail
    ctx.beginPath();
    ctx.arc(0, 0, 48, Math.max(startAngle, currentAngle - 0.7), currentAngle, false);
    ctx.strokeStyle = "rgba(72, 202, 228, 0.85)";
    ctx.lineWidth = 14;
    ctx.lineCap = "round";
    ctx.stroke();

    // 3. Razor-sharp white luminous cutting edge
    ctx.beginPath();
    ctx.arc(0, 0, 48, Math.max(startAngle, currentAngle - 0.35), currentAngle, false);
    ctx.strokeStyle = "rgba(255, 255, 255, 0.98)";
    ctx.lineWidth = 5;
    ctx.lineCap = "round";
    ctx.stroke();

    // 4. Slashing tip particle sparks along the blade arc tip
    const tipX = Math.cos(currentAngle) * 48;
    const tipY = Math.sin(currentAngle) * 48;
    ctx.fillStyle = "#ffffff";
    ctx.beginPath();
    ctx.arc(tipX, tipY, 4.5, 0, Math.PI * 2);
    ctx.fill();

    // 5. Steel Longsword with golden crossguard and pommel rotated to the current swing angle
    ctx.rotate(currentAngle);

    // Pommel (golden ring)
    ctx.fillStyle = "#d4af37";
    ctx.beginPath();
    ctx.arc(0, 0, 3.5, 0, Math.PI * 2);
    ctx.fill();

    // Leather wrapped grip
    ctx.fillStyle = "#5c3d2e";
    ctx.fillRect(2, -2, 7, 4);

    // Golden crossguard
    ctx.fillStyle = "#ffd166";
    ctx.fillRect(8, -8, 4, 16);
    ctx.fillStyle = "#d4af37";
    ctx.fillRect(8, -8, 4, 2);
    ctx.fillRect(8, 6, 4, 2);

    // Steel blade
    ctx.fillStyle = "#e9ecef";
    ctx.fillRect(12, -3, 30, 6);

    // Blade fuller / center ridge highlight
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(12, -1, 28, 2);

    // Tapered sharp blade tip
    ctx.fillStyle = "#ced4da";
    ctx.beginPath();
    ctx.moveTo(42, -3);
    ctx.lineTo(48, 0);
    ctx.lineTo(42, 3);
    ctx.closePath();
    ctx.fill();

    ctx.restore();
  }
}


function drawAtmosphere() {
  particles.forEach(p => {
    ctx.fillStyle = p.color;
    ctx.globalAlpha = Math.max(0, p.life / p.maxLife);
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
    ctx.fill();
  });
  ctx.globalAlpha = 1.0;

  damageTexts.forEach(t => {
    ctx.save();
    ctx.font = t.isCrit ? "bold 18px sans-serif" : "bold 14px sans-serif";
    ctx.fillStyle = t.color;
    ctx.textAlign = "center";
    ctx.shadowColor = "#000000";
    ctx.shadowBlur = 5;
    ctx.fillText(t.text, t.x, t.y);
    ctx.restore();
  });

  clouds.forEach(c => {
    ctx.fillStyle = `rgba(0, 0, 0, ${c.alpha})`;
    ctx.beginPath();
    ctx.ellipse(c.x, c.y, 90 * c.scale, 50 * c.scale, 0, 0, Math.PI * 2);
    ctx.ellipse(c.x + 40 * c.scale, c.y - 15 * c.scale, 70 * c.scale, 40 * c.scale, 0, 0, Math.PI * 2);
    ctx.fill();
  });
}

// ------------------------------------------
// HUD & Touch Controls (Unchanged)
// ------------------------------------------
let isStatusWindowOpen = false;

function toggleStatusWindow() {
  isStatusWindowOpen = !isStatusWindowOpen;
  playSound("coin");
}

function handleStatusWindowClick(clickX, clickY) {
  if (!isStatusWindowOpen) return false;

  const winW = 540;
  const winH = 340;
  const winX = (VIRTUAL_WIDTH - winW) / 2;
  const winY = (VIRTUAL_HEIGHT - winH) / 2;

  // Check Close Button (top-right corner of window)
  const closeBtnX = winX + winW - 38;
  const closeBtnY = winY + 12;
  if (clickX >= closeBtnX - 10 && clickX <= closeBtnX + 28 && clickY >= closeBtnY - 6 && clickY <= closeBtnY + 32) {
    isStatusWindowOpen = false;
    playSound("grass");
    return true;
  }

  // Check stat allocation '+' buttons (on right panel)
  if (player.statPoints > 0) {
    const col2X = winX + 285;
    const statsList = ["str", "vit", "int", "dex"];
    for (let i = 0; i < statsList.length; i++) {
      const btnX = col2X + 210;
      const btnY = winY + 104 + i * 44;
      // 28x28 hit area
      if (clickX >= btnX - 6 && clickX <= btnX + 32 && clickY >= btnY - 18 && clickY <= btnY + 16) {
        allocateStatPoint(statsList[i]);
        return true;
      }
    }
  }

  // If clicked inside the status window, consume the click so character doesn't swing sword
  if (clickX >= winX && clickX <= winX + winW && clickY >= winY && clickY <= winY + winH) {
    return true;
  }

  // Clicked outside window: close window
  isStatusWindowOpen = false;
  playSound("grass");
  return true;
}

function drawStatusWindow() {
  if (!isStatusWindowOpen) return;

  const winW = 560;
  const winH = 340;
  const winX = (VIRTUAL_WIDTH - winW) / 2;
  const winY = (VIRTUAL_HEIGHT - winH) / 2;

  // Backdrop shadow overlay
  ctx.fillStyle = "rgba(5, 10, 18, 0.65)";
  ctx.fillRect(0, 0, VIRTUAL_WIDTH, VIRTUAL_HEIGHT);

  // Main Window Card
  ctx.fillStyle = "rgba(15, 23, 42, 0.96)";
  ctx.strokeStyle = "#c2a679";
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.roundRect(winX, winY, winW, winH, 16);
  ctx.fill();
  ctx.stroke();

  // Header Title Bar
  ctx.fillStyle = "#1e293b";
  ctx.beginPath();
  ctx.roundRect(winX + 4, winY + 4, winW - 8, 44, [12, 12, 0, 0]);
  ctx.fill();

  ctx.fillStyle = "#ffd166";
  ctx.font = "bold 16px sans-serif";
  ctx.textAlign = "left";
  ctx.fillText("✦ CHARACTER STATUS ✦", winX + 24, winY + 31);

  // Close 'X' Button
  const closeBtnX = winX + winW - 36;
  const closeBtnY = winY + 26;
  ctx.fillStyle = "#ef233c";
  ctx.beginPath();
  ctx.arc(closeBtnX, closeBtnY, 13, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "#ffffff";
  ctx.lineWidth = 1.5;
  ctx.stroke();

  ctx.fillStyle = "#ffffff";
  ctx.font = "bold 13px sans-serif";
  ctx.textAlign = "center";
  ctx.fillText("✕", closeBtnX, closeBtnY + 4.5);

  // Available Stat Points Banner
  ctx.fillStyle = player.statPoints > 0 ? "rgba(255, 209, 102, 0.2)" : "rgba(100, 116, 139, 0.15)";
  ctx.strokeStyle = player.statPoints > 0 ? "#ffd166" : "#475569";
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.roundRect(winX + 24, winY + 56, winW - 48, 30, 8);
  ctx.fill();
  ctx.stroke();

  ctx.fillStyle = player.statPoints > 0 ? "#ffd166" : "#cbd5e1";
  ctx.font = "bold 12px sans-serif";
  ctx.textAlign = "left";
  ctx.fillText(`Available Stat Points: ${player.statPoints}`, winX + 38, winY + 75);

  ctx.fillStyle = "#94a3b8";
  ctx.font = "italic 11px sans-serif";
  ctx.textAlign = "right";
  ctx.fillText("(+3 points per level up)", winX + winW - 38, winY + 75);

  // Column 1: Core Combat Attributes
  const col1X = winX + 24;
  const col1W = 240;
  ctx.fillStyle = "rgba(30, 41, 59, 0.5)";
  ctx.beginPath();
  ctx.roundRect(col1X, winY + 94, col1W, 226, 10);
  ctx.fill();

  ctx.fillStyle = "#ffd166";
  ctx.font = "bold 12px sans-serif";
  ctx.textAlign = "left";
  ctx.fillText("ATTRIBUTES", col1X + 16, winY + 116);

  const attributes = [
    { label: "Level", val: `${player.level}` },
    { label: "HP (Health)", val: `${Math.round(player.hp)} / ${player.maxHp}` },
    { label: "MP (Mana)", val: `${Math.round(player.mp)} / ${player.maxMp}` },
    { label: "EXP", val: `${player.exp} / ${player.maxExp}` },
    { label: "Attack", val: `${player.attack}` },
    { label: "Defense", val: `${player.defense}` },
    { label: "Attack Speed", val: `${(1 / player.attackDuration).toFixed(1)} /s` }
  ];

  attributes.forEach((attr, idx) => {
    const rowY = winY + 142 + idx * 24;
    ctx.fillStyle = "#94a3b8";
    ctx.font = "11px sans-serif";
    ctx.textAlign = "left";
    ctx.fillText(attr.label, col1X + 16, rowY);

    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 12px sans-serif";
    ctx.textAlign = "right";
    ctx.fillText(attr.val, col1X + col1W - 16, rowY);
  });

  // Column 2: Allocatable Stats (STR, VIT, INT, DEX)
  const col2X = winX + 280;
  const col2W = 256;
  ctx.fillStyle = "rgba(30, 41, 59, 0.5)";
  ctx.beginPath();
  ctx.roundRect(col2X, winY + 94, col2W, 226, 10);
  ctx.fill();

  ctx.fillStyle = "#ffd166";
  ctx.font = "bold 12px sans-serif";
  ctx.textAlign = "left";
  ctx.fillText("PRIMARY STATS", col2X + 16, winY + 116);

  const statDefs = [
    { key: "str", name: "Strength", val: player.str, desc: "Increases Attack (+2 per pt)" },
    { key: "vit", name: "Vitality", val: player.vit, desc: "Increases Max HP & Defense" },
    { key: "int", name: "Intelligence", val: player.int, desc: "Increases Max MP (+10 per pt)" },
    { key: "dex", name: "Dexterity", val: player.dex, desc: "Increases Attack Speed" }
  ];

  statDefs.forEach((st, idx) => {
    const rowY = winY + 144 + idx * 44;

    // Stat name & value
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 13px sans-serif";
    ctx.textAlign = "left";
    ctx.fillText(st.name, col2X + 16, rowY);

    ctx.fillStyle = "#ffd166";
    ctx.font = "bold 14px sans-serif";
    ctx.textAlign = "right";
    ctx.fillText(`${st.val}`, col2X + col2W - 54, rowY);

    // Stat explanation subtitle
    ctx.fillStyle = "#64748b";
    ctx.font = "10px sans-serif";
    ctx.textAlign = "left";
    ctx.fillText(st.desc, col2X + 16, rowY + 14);

    // '+' Allocation Button
    const btnX = col2X + col2W - 36;
    const btnY = rowY - 5;
    const hasPoints = player.statPoints > 0;

    ctx.fillStyle = hasPoints ? "#2a9d8f" : "#334155";
    ctx.strokeStyle = hasPoints ? "#52b788" : "#475569";
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.roundRect(btnX - 12, btnY - 12, 24, 24, 6);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = hasPoints ? "#ffffff" : "#64748b";
    ctx.font = "bold 16px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("+", btnX, btnY + 5);
  });
}

function drawHUD() {
  ctx.setTransform(1, 0, 0, 1, 0, 0);

  drawPlayerHUD(20, 20);

  ctx.fillStyle = "rgba(13, 19, 26, 0.75)";
  ctx.strokeStyle = "#c2a679";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.roundRect(VIRTUAL_WIDTH / 2 - 125, 16, 250, 36, 8);
  ctx.fill();
  ctx.stroke();

  ctx.fillStyle = "#ffd166";
  ctx.font = "bold 14px sans-serif";
  ctx.textAlign = "center";
  ctx.fillText("✦ OAKHAVEN VILLAGE ✦", VIRTUAL_WIDTH / 2, 38);

  drawTopRightControls();
  drawVirtualJoystick();
  drawActionButtons();

  if (activeDialogue) {
    drawDialogueBox();
  }

  // Character Status Modal Window
  drawStatusWindow();
}

function drawPlayerHUD(x, y) {
  const hudW = 245;
  const hudH = 88;

  // Background frame
  ctx.fillStyle = "rgba(15, 23, 42, 0.88)";
  ctx.strokeStyle = "#c2a679";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.roundRect(x, y, hudW, hudH, 12);
  ctx.fill();
  ctx.stroke();

  // Knight avatar circular portrait
  ctx.fillStyle = "#1d3557";
  ctx.beginPath();
  ctx.arc(x + 36, y + 44, 25, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "#ffd166";
  ctx.lineWidth = 2.5;
  ctx.stroke();

  // Knight avatar portrait from turnaround spritesheet (frame 0: south facing)
  const knightImg = ASSETS.knightTurnaround;
  if (knightImg && knightImg.complete && knightImg.naturalWidth > 0) {
    ctx.save();
    ctx.beginPath();
    ctx.arc(x + 36, y + 44, 23, 0, Math.PI * 2);
    ctx.clip();
    // Knight face is located in frame 0 roughly at sx: 18..46, sy: 6..36
    ctx.drawImage(knightImg, 16, 6, 32, 32, x + 18, y + 26, 36, 36);
    ctx.restore();
  } else {
    ctx.fillStyle = "#adb5bd";
    ctx.beginPath();
    ctx.arc(x + 36, y + 44, 13, 0, Math.PI * 2);
    ctx.fill();
  }

  // Level Badge overlapping avatar corner
  ctx.fillStyle = "#ffd166";
  ctx.beginPath();
  ctx.roundRect(x + 8, y + 58, 56, 18, 9);
  ctx.fill();
  ctx.strokeStyle = "#4a3b1a";
  ctx.lineWidth = 1.5;
  ctx.stroke();

  ctx.fillStyle = "#1b263b";
  ctx.font = "bold 10px sans-serif";
  ctx.textAlign = "center";
  ctx.fillText(`Lv. ${player.level}`, x + 36, y + 71);

  const barX = x + 72;
  const barW = 158;

  // 1. Health Bar
  const hpBarY = y + 12;
  const hpBarH = 16;
  ctx.fillStyle = "#331818";
  ctx.beginPath();
  ctx.roundRect(barX, hpBarY, barW, hpBarH, 4);
  ctx.fill();

  const hpRatio = Math.max(0, player.hp / player.maxHp);
  const hpGrad = ctx.createLinearGradient(barX, 0, barX + barW, 0);
  hpGrad.addColorStop(0, "#e63946");
  hpGrad.addColorStop(1, "#ff758f");
  ctx.fillStyle = hpGrad;
  ctx.beginPath();
  ctx.roundRect(barX, hpBarY, barW * hpRatio, hpBarH, 4);
  ctx.fill();

  ctx.fillStyle = "#ffffff";
  ctx.font = "bold 10px sans-serif";
  ctx.textAlign = "left";
  ctx.fillText(`HP ${Math.round(player.hp)}/${player.maxHp}`, barX + 6, hpBarY + 12);

  // 2. MP Bar (Mana Points from Intelligence)
  const mpBarY = y + 31;
  const mpBarH = 12;
  ctx.fillStyle = "#14213d";
  ctx.beginPath();
  ctx.roundRect(barX, mpBarY, barW, mpBarH, 3);
  ctx.fill();

  const mpRatio = Math.max(0, player.mp / player.maxMp);
  const mpGrad = ctx.createLinearGradient(barX, 0, barX + barW, 0);
  mpGrad.addColorStop(0, "#4361ee");
  mpGrad.addColorStop(1, "#4cc9f0");
  ctx.fillStyle = mpGrad;
  ctx.beginPath();
  ctx.roundRect(barX, mpBarY, barW * mpRatio, mpBarH, 3);
  ctx.fill();

  ctx.fillStyle = "#ffffff";
  ctx.font = "bold 8px sans-serif";
  ctx.fillText(`MP ${Math.round(player.mp)}/${player.maxMp}`, barX + 6, mpBarY + 9);

  // 3. Stamina Bar
  const stBarY = y + 46;
  const stBarH = 11;
  ctx.fillStyle = "#1b263b";
  ctx.beginPath();
  ctx.roundRect(barX, stBarY, barW, stBarH, 3);
  ctx.fill();

  const stRatio = Math.max(0, player.stamina / player.maxStamina);
  ctx.fillStyle = "#00b4d8";
  ctx.beginPath();
  ctx.roundRect(barX, stBarY, barW * stRatio, stBarH, 3);
  ctx.fill();

  ctx.fillStyle = "#e0e1dd";
  ctx.font = "bold 8px sans-serif";
  ctx.fillText(`STAMINA`, barX + 6, stBarY + 9);

  // 4. EXP Bar (Current EXP vs Required EXP for next level)
  const expBarY = y + 61;
  const expBarH = 13;
  ctx.fillStyle = "#1a2215";
  ctx.beginPath();
  ctx.roundRect(barX, expBarY, barW, expBarH, 3);
  ctx.fill();

  const expRatio = Math.min(1, Math.max(0, player.exp / player.maxExp));
  const expGrad = ctx.createLinearGradient(barX, 0, barX + barW, 0);
  expGrad.addColorStop(0, "#52b788");
  expGrad.addColorStop(1, "#74c69d");
  ctx.fillStyle = expGrad;
  ctx.beginPath();
  ctx.roundRect(barX, expBarY, barW * expRatio, expBarH, 3);
  ctx.fill();

  ctx.fillStyle = "#ffffff";
  ctx.font = "bold 9px sans-serif";
  ctx.fillText(`EXP ${player.exp}/${player.maxExp}`, barX + 6, expBarY + 10);
}

function drawTopRightControls() {
  // Status Button
  const statBtnX = VIRTUAL_WIDTH - 250;
  const statBtnY = 20;
  const statBtnW = 92;
  const statBtnH = 36;

  ctx.fillStyle = isStatusWindowOpen ? "rgba(247, 127, 0, 0.85)" : "rgba(15, 23, 42, 0.85)";
  ctx.strokeStyle = player.statPoints > 0 ? "#ffd166" : "#48cae4";
  ctx.lineWidth = 1.8;
  ctx.beginPath();
  ctx.roundRect(statBtnX, statBtnY, statBtnW, statBtnH, 18);
  ctx.fill();
  ctx.stroke();

  // Helmet / Character Icon
  ctx.fillStyle = "#ffd166";
  ctx.beginPath();
  ctx.arc(statBtnX + 20, statBtnY + 18, 9, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#1b263b";
  ctx.fillRect(statBtnX + 16, statBtnY + 16, 8, 3);

  ctx.fillStyle = "#ffffff";
  ctx.font = "bold 11px sans-serif";
  ctx.textAlign = "left";
  ctx.fillText("STATUS", statBtnX + 35, statBtnY + 23);

  // Unspent stat points indicator badge
  if (player.statPoints > 0) {
    const pulse = Math.sin(performance.now() * 0.008) * 1.5;
    ctx.fillStyle = "#e63946";
    ctx.beginPath();
    ctx.arc(statBtnX + statBtnW - 4, statBtnY + 4, 8 + pulse, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "#ffffff";
    ctx.lineWidth = 1.5;
    ctx.stroke();

    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 9px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(`${player.statPoints}`, statBtnX + statBtnW - 4, statBtnY + 7);
  }

  // Gold indicator
  const goldX = VIRTUAL_WIDTH - 150;
  const goldY = 20;
  ctx.fillStyle = "rgba(15, 23, 42, 0.85)";
  ctx.strokeStyle = "#ffd166";
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.roundRect(goldX, goldY, 95, 36, 18);
  ctx.fill();
  ctx.stroke();

  ctx.fillStyle = "#ffd166";
  ctx.beginPath();
  ctx.arc(goldX + 20, goldY + 18, 10, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#d4a373";
  ctx.beginPath();
  ctx.arc(goldX + 20, goldY + 18, 7, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "#ffffff";
  ctx.font = "bold 13px sans-serif";
  ctx.textAlign = "left";
  ctx.fillText(`${player.gold} G`, goldX + 38, goldY + 23);

  // Sound toggle button
  const soundX = VIRTUAL_WIDTH - 42;
  const soundY = 38;
  ctx.fillStyle = "rgba(15, 23, 42, 0.85)";
  ctx.strokeStyle = soundEnabled ? "#52b788" : "#e63946";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(soundX, soundY, 18, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  ctx.fillStyle = soundEnabled ? "#52b788" : "#adb5bd";
  ctx.beginPath();
  ctx.moveTo(soundX - 7, soundY - 4);
  ctx.lineTo(soundX - 2, soundY - 4);
  ctx.lineTo(soundX + 4, soundY - 9);
  ctx.lineTo(soundX + 4, soundY + 9);
  ctx.lineTo(soundX - 2, soundY + 4);
  ctx.lineTo(soundX - 7, soundY + 4);
  ctx.closePath();
  ctx.fill();

  if (soundEnabled) {
    ctx.strokeStyle = "#52b788";
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(soundX + 6, soundY, 5, -Math.PI * 0.3, Math.PI * 0.3);
    ctx.stroke();
  } else {
    ctx.strokeStyle = "#e63946";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(soundX - 10, soundY - 10);
    ctx.lineTo(soundX + 10, soundY + 10);
    ctx.stroke();
  }
}

function drawVirtualJoystick() {
  const base = joystick;

  ctx.save();
  ctx.fillStyle = "rgba(15, 23, 42, 0.45)";
  ctx.beginPath();
  ctx.arc(base.baseX, base.baseY, base.radius, 0, Math.PI * 2);
  ctx.fill();

  ctx.strokeStyle = "rgba(255, 209, 102, 0.55)";
  ctx.lineWidth = 3;
  ctx.stroke();

  const arrowDist = base.radius * 0.72;
  ctx.fillStyle = "rgba(255, 255, 255, 0.35)";
  // Up
  ctx.beginPath();
  ctx.moveTo(base.baseX, base.baseY - arrowDist);
  ctx.lineTo(base.baseX - 6, base.baseY - arrowDist + 8);
  ctx.lineTo(base.baseX + 6, base.baseY - arrowDist + 8);
  ctx.fill();
  // Down
  ctx.beginPath();
  ctx.moveTo(base.baseX, base.baseY + arrowDist);
  ctx.lineTo(base.baseX - 6, base.baseY + arrowDist - 8);
  ctx.lineTo(base.baseX + 6, base.baseY + arrowDist - 8);
  ctx.fill();
  // Left
  ctx.beginPath();
  ctx.moveTo(base.baseX - arrowDist, base.baseY);
  ctx.lineTo(base.baseX - arrowDist + 8, base.baseY - 6);
  ctx.lineTo(base.baseX - arrowDist + 8, base.baseY + 6);
  ctx.fill();
  // Right
  ctx.beginPath();
  ctx.moveTo(base.baseX + arrowDist, base.baseY);
  ctx.lineTo(base.baseX + arrowDist - 8, base.baseY - 6);
  ctx.lineTo(base.baseX + arrowDist - 8, base.baseY + 6);
  ctx.fill();

  if (base.active) {
    ctx.strokeStyle = "rgba(255, 209, 102, 0.7)";
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(base.baseX, base.baseY);
    ctx.lineTo(base.currX, base.currY);
    ctx.stroke();
  }

  const knobGrad = ctx.createRadialGradient(
    base.currX - 6, base.currY - 6, 2,
    base.currX, base.currY, base.knobRadius
  );
  if (base.active) {
    knobGrad.addColorStop(0, "#ffd166");
    knobGrad.addColorStop(1, "#d4a373");
  } else {
    knobGrad.addColorStop(0, "#4a5568");
    knobGrad.addColorStop(1, "#1a202c");
  }
  ctx.fillStyle = knobGrad;
  ctx.beginPath();
  ctx.arc(base.currX, base.currY, base.knobRadius, 0, Math.PI * 2);
  ctx.fill();

  ctx.strokeStyle = "#ffffff";
  ctx.lineWidth = 2;
  ctx.stroke();

  ctx.restore();
}

function drawActionButtons() {
  // Attack Button (Bottom-Right)
  const btn = attackButton;
  const isPressed = btn.pressed || player.isAttacking;
  const scale = isPressed ? 0.92 : 1.0;

  ctx.save();
  ctx.translate(btn.x, btn.y);
  ctx.scale(scale, scale);

  ctx.fillStyle = "#ffd166";
  ctx.beginPath();
  ctx.arc(0, 0, btn.radius, 0, Math.PI * 2);
  ctx.fill();

  const rubyGrad = ctx.createRadialGradient(-10, -10, 5, 0, 0, btn.radius - 4);
  rubyGrad.addColorStop(0, "#ff4d6d");
  rubyGrad.addColorStop(0.7, "#c9184a");
  rubyGrad.addColorStop(1, "#800f2f");
  ctx.fillStyle = rubyGrad;
  ctx.beginPath();
  ctx.arc(0, 0, btn.radius - 4, 0, Math.PI * 2);
  ctx.fill();

  ctx.strokeStyle = "#ffffff";
  ctx.lineWidth = 3.5;
  ctx.lineCap = "round";

  ctx.beginPath();
  ctx.moveTo(-16, 16);
  ctx.lineTo(16, -16);
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(-18, 4);
  ctx.lineTo(-6, 16);
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(16, 16);
  ctx.lineTo(-16, -16);
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(18, 4);
  ctx.lineTo(6, 16);
  ctx.stroke();

  ctx.fillStyle = "#ffffff";
  ctx.font = "bold 11px sans-serif";
  ctx.textAlign = "center";
  ctx.shadowColor = "#000000";
  ctx.shadowBlur = 4;
  ctx.fillText("ATTACK", 0, 30);
  ctx.shadowBlur = 0;

  ctx.restore();

  // Dash Button
  const dBtn = dashButton;
  const isDashPressed = dBtn.pressed || player.isDashing;
  const dScale = isDashPressed ? 0.92 : 1.0;

  ctx.save();
  ctx.translate(dBtn.x, dBtn.y);
  ctx.scale(dScale, dScale);

  ctx.fillStyle = "#48cae4";
  ctx.beginPath();
  ctx.arc(0, 0, dBtn.radius, 0, Math.PI * 2);
  ctx.fill();

  const dashGrad = ctx.createRadialGradient(-6, -6, 2, 0, 0, dBtn.radius - 3);
  dashGrad.addColorStop(0, "#0096c7");
  dashGrad.addColorStop(1, "#03045e");
  ctx.fillStyle = dashGrad;
  ctx.beginPath();
  ctx.arc(0, 0, dBtn.radius - 3, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "#ffffff";
  ctx.beginPath();
  ctx.moveTo(-12, 4);
  ctx.lineTo(12, -4);
  ctx.lineTo(-4, -12);
  ctx.closePath();
  ctx.fill();

  ctx.font = "bold 10px sans-serif";
  ctx.textAlign = "center";
  ctx.fillText("DASH", 0, 20);

  ctx.restore();

  // Talk / Interact Button
  const iBtn = interactButton;
  ctx.save();
  ctx.translate(iBtn.x, iBtn.y);
  if (iBtn.pressed) ctx.scale(0.92, 0.92);

  ctx.fillStyle = "#ffd166";
  ctx.beginPath();
  ctx.arc(0, 0, iBtn.radius, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "#2b2d42";
  ctx.beginPath();
  ctx.arc(0, 0, iBtn.radius - 3, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "#ffd166";
  ctx.beginPath();
  ctx.roundRect(-12, -10, 24, 16, 4);
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(-4, 6);
  ctx.lineTo(2, 6);
  ctx.lineTo(-2, 11);
  ctx.closePath();
  ctx.fill();

  ctx.fillStyle = "#ffffff";
  ctx.font = "bold 9px sans-serif";
  ctx.textAlign = "center";
  ctx.fillText("TALK", 0, 18);

  ctx.restore();
}

function drawDialogueBox() {
  const boxW = 680;
  const boxH = 110;
  const boxX = (VIRTUAL_WIDTH - boxW) / 2;
  const boxY = VIRTUAL_HEIGHT - 130;

  ctx.fillStyle = "rgba(15, 23, 42, 0.94)";
  ctx.strokeStyle = "#ffd166";
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.roundRect(boxX, boxY, boxW, boxH, 14);
  ctx.fill();
  ctx.stroke();

  ctx.fillStyle = "#ffd166";
  ctx.font = "bold 15px sans-serif";
  ctx.textAlign = "left";
  ctx.fillText(`✦ ${activeDialogue.name} (${activeDialogue.title})`, boxX + 24, boxY + 28);

  ctx.fillStyle = "#e2e8f0";
  ctx.font = "14px sans-serif";
  wrapText(activeDialogue.text, boxX + 24, boxY + 54, boxW - 48, 22);

  ctx.fillStyle = "#94a3b8";
  ctx.font = "italic 11px sans-serif";
  ctx.textAlign = "right";
  ctx.fillText("Tap anywhere to close", boxX + boxW - 20, boxY + boxH - 12);
}

function wrapText(text, x, y, maxWidth, lineHeight) {
  const words = text.split(" ");
  let line = "";
  for (let n = 0; n < words.length; n++) {
    const testLine = line + words[n] + " ";
    const metrics = ctx.measureText(testLine);
    if (metrics.width > maxWidth && n > 0) {
      ctx.fillText(line, x, y);
      line = words[n] + " ";
      y += lineHeight;
    } else {
      line = testLine;
    }
  }
  ctx.fillText(line, x, y);
}

// ------------------------------------------
// Main Loop
// ------------------------------------------
function gameLoop(now) {
  const dt = Math.min((now - lastTime) / 1000, 0.1);
  lastTime = now;

  update(dt);

  ctx.clearRect(0, 0, VIRTUAL_WIDTH, VIRTUAL_HEIGHT);

  ctx.save();
  const shakeX = (Math.random() - 0.5) * camera.shake;
  const shakeY = (Math.random() - 0.5) * camera.shake;
  ctx.translate(-Math.round(camera.x + shakeX), -Math.round(camera.y + shakeY));

  // 1. Draw Ground, Grass, Cobblestone Paths, Plaza, River, and Bridge
  drawCainosMap();

  // 2. Draw Y-Sorted Entities, Buildings, Trees, Props, NPCs, Slimes, and Player
  drawCainosEntities();

  // 3. Draw Atmosphere, Clouds, Particles, Floating Text
  drawAtmosphere();

  ctx.restore();

  // 4. Draw HUD
  drawHUD();

  requestAnimationFrame(gameLoop);
}

requestAnimationFrame(gameLoop);
